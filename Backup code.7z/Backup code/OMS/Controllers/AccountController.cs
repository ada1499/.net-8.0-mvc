﻿namespace OMS.Controllers
{
    public class AccountController : Controller
    {
        private readonly AllServices _services;

        public AccountController(AllServices services) => _services = services;

        public IActionResult Index()
        {
            //var username = User.FindFirstValue(ClaimTypes.Name);
            var username = "Admin";
            var clientIp = HttpContext.Connection.RemoteIpAddress?.ToString();

            _services.UserSessionCache.UpdateSession(username!, clientIp!);

            return RedirectToAction("Index", "Home");
        }
    }
}
