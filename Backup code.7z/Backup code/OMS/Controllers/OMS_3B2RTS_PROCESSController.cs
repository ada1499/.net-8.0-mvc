﻿using Model = OMS.Models.OMS_3B2RTS_PROCESS;
using ModelSearch = OMS.Models.OMS_3B2RTS_PROCESS_Search;

namespace OMS.Controllers
{
    public class OMS_3B2RTS_PROCESSController : BaseController<Model>
    {
        private const string SpName = "OMS_3B2RTS_WEB";
        private const string FuncGetData = "GET_3B2RTS_PROCESS_DATA";
        private const string FuncCommit = "COMMIT_3B2RTS_PROCESS";
        private const string FuncInsert = "INSERT_3B2RTS_PROCESS";

        public OMS_3B2RTS_PROCESSController(AllServices services)
            : base(services, SpName)
        {
        }

        public async Task<IActionResult> Index()
            => await PartialView("3B2RTS_PROCESS", FuncGetData);

        [HttpPost]
        public async Task<IActionResult> Search([FromForm] ModelSearch request)
            => await ModelData(FuncGetData, request);

        [HttpPost]
        public async Task<IActionResult> Update([FromBody] List<Model> request)
            => await ExcuteStoredProcedure(FuncCommit, request);

        [HttpPost]
        public async Task<IActionResult> UploadExcel([FromBody] List<Model> request)
            => await ExcuteStoredProcedure(FuncInsert, request);
    }
}
