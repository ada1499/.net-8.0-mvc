﻿using OMS.Services.Api.Builders;
using Model = OMS.Models.OMS_3B18_MAIN;
using ModelSearch = OMS.Models.OMS_3B18_MAIN_Search;

namespace OMS.Controllers
{
    public class OMS_3B18_MAINController : BaseController<Model>
    {
        private const string SpName = "OMS_3B18_WEB";
        private const string FuncGetData = "GET_3B18_MAIN_DATA";
        private const string FuncCommit = "COMMIT_3B18_MAIN";
        private const string EndpointName = "SapApi";

        public OMS_3B18_MAINController(AllServices services)
            : base(services, SpName)
        {
        }

        public async Task<IActionResult> Index()
            => await PartialView("3B18_MAIN", FuncGetData);

        [HttpPost]
        public async Task<IActionResult> Search([FromForm] ModelSearch request)
            => await ModelData(FuncGetData, request);

        [HttpPost]
        public async Task<IActionResult> Update([FromBody] List<Model> request)
        {
            var requestData = new SapRequestBuilder()
                .WithFunction("ZCSD_NSBG_0037")
                .AddInputTable("I_TAB", new()
                {
                    ["MATNR"] = "68-6265-07",
                    ["WERKS"] = "MCGA"
                })
                .build();

            return await CallApi(EndpointName, HttpMethod.Post, requestData);
        }
    }
}
