﻿using OMS.Models.Api;

namespace OMS.Controllers
{
    public abstract class BaseController<TModel>(AllServices services, string spName) : Controller where TModel : class
    {
        protected readonly AllServices _services = services;
        protected readonly string _spName = spName;

        public async Task<IActionResult> CallService<TResult>(Func<AllServices, SqlParameter[], Task<TResult>> serviceCall, string funcName, object? request = null)
        {
            var parameters = BuildSqlParameters(funcName, request);
            return Ok(await serviceCall(_services, parameters));
        }

        public virtual async Task<IActionResult> PartialView(string view, string funcName)
        {
            var parameters = BuildSqlParameters(funcName);
            var viewModel = await _services.DbService.GetModelDataAsync<TModel>(_spName, parameters, true);
            return PartialView(view, viewModel);
        }

        public virtual async Task<IActionResult> ModelData(string funcName, object request)
            => await CallService(
                async (services, p) => (await services.DbService.GetModelDataAsync<TModel>(_spName, p, true)).Data,
                funcName,
                request);

        public virtual async Task<IActionResult> ExcuteStoredProcedure(string funcName, object request)
            => await CallService(
                async (services, p) => await _services.DbService.ExecuteDynamicAsync(_spName, p, true),
                funcName,
                request);

        public virtual async Task<IActionResult> CallApi(string endpoint, HttpMethod method, object? request = null, Dictionary<string, string>? parameters = null)
        {
            var response = await _services.ApiService.SendAsync<ApiResponse>(endpoint, method, request, parameters);
            return Ok(response);
        }

        private static SqlParameter[] BuildSqlParameters(string funcName, object? parameters = null)
            => parameters switch
            {
                null => [new("@FUNCTION", funcName)],
                _ => [
                    new("@FUNCTION", funcName),
                    new("@JSON", JsonSerializer.Serialize(parameters))
                    {
                        SqlDbType = SqlDbType.NVarChar,
                        Size = -1
                    }]
            };
    }
}
