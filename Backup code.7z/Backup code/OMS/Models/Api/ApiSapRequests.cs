﻿namespace OMS.Models.Api
{
    public record ApiSapRequest(
        string FuncName,
        RequestSapInput Input,
        RequestSapOutput Output
    );

    public record RequestSapInput(
        Dictionary<string, string> InValue,
        Dictionary<string, Dictionary<string, string>> Table
    );

    public record RequestSapOutput(
        List<string> OutValue,
        List<string> Table
    );
}
