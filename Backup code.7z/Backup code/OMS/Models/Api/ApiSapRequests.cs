﻿namespace OMS.Models.Api
{
    public record ApiSapRequest(
        string FuncName,
        RequestSapInput Input
    );

    public record RequestSapInput(
        Dictionary<string, string> InValue,
        Dictionary<string, Dictionary<string, string>> Table
    );
}
