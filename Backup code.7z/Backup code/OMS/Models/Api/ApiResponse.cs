﻿namespace OMS.Models.Api
{
    public record ApiResponse(bool Success, object? Data);
}
