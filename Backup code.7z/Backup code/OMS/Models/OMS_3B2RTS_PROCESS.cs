﻿namespace OMS.Models
{
    public class OMS_3B2RTS_PROCESS
    {
        public int FLAG { get; set; }
        public int ID { get; set; }
        public required string F_SHIPVIA { get; set; }
        public required string F_PLANT { get; set; }
        public required string F_VENDORCODE { get; set; }
        public required string F_PO { get; set; }
        public required string F_ITEM { get; set; }
        public required string F_NEWLINE { get; set; }
        public required string F_PN { get; set; }
        public DateTime F_ETD { get; set; }
        public DateTime F_COMMITDELIVERYDATE { get; set; }
        public int F_COMMITDELIVERYQTY { get; set; }
        public required string F_POTYPE { get; set; }
        public required string F_EXPEDITEFLAG { get; set; }
        public required string F_PACKTYPE { get; set; }
        public string? F_APPROVALID { get; set; }
        public string? BU { get; set; }
        public string? PRODUCT_FAMILY { get; set; }
    }

    public class OMS_3B2RTS_PROCESS_Search
    {
        public string? VendorCode { get; set; }
        public string? Plant { get; set; }
        public DateTime? ETD { get; set; }
        public string? POType { get; set; }
        public string? PN { get; set; }
        public string? PO { get; set; }
        public string? Item { get; set; }
        public string? Line { get; set; }
    }
}
