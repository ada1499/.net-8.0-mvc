﻿namespace OMS.Models
{
    public class OMS_3B18_MAIN
    {
        public int FLAG { get; set; }
        public required string SHIP_FROM { get; set; }
        public required string SHIP_TO { get; set; }
        public required string PO { get; set; }
        public required string PN { get; set; }
        public required string ITEM { get; set; }
        public required string LINE { get; set; }
        public int? SHIPPED_QUANTITY { get; set; }
        public int? DN_QTY { get; set; }
        public string? DN_NO { get; set; }
        public string? DELIVERY_ID { get; set; }
        public string? EXPEDITE { get; set; }
        public string? CARRIER_CODE { get; set; }
        public DateTime ETA { get; set; }
        public string? DN_MESSAGE { get; set; }
        public string? SO { get; set; }
        public string? REC_ID { get; set; }
    }

    public class OMS_3B18_MAIN_Search
    {
        public string? SHIP_FROM { get; set; }
        public string? SHIP_TO { get; set; }
        public DateTime? ETA { get; set; }
        public string? PN { get; set; }
        public string? PO { get; set; }
        public string? Item { get; set; }
        public string? Line { get; set; }
    }

    public record OMS_3B18_MAIN_Update(
        string SHIP_FROM,
        string SHIP_TO,
        string SHIP_VIA,
        string DELIVERY_ID,
        int DN_QTY,
        string USER_ID);
}
