﻿namespace OMS.Models
{
    public class OMS_3B2RTS_MAIN
    {
        public int FLAG { get; set; }
        public required string SHIP_TO_NAME { get; set; }
        public required string SENDER_DUNS_NUMBER { get; set; }
        public required string PO { get; set; }
        public required string PN { get; set; }
        public int SHIPPED_QUANTITY { get; set; }
        public string? PLANT { get; set; }
        public required string SHIP_VIA { get; set; }
        public required string ITEM_NUMBER { get; set; }
        public required string PO_LINE_NUMBER { get; set; }
        public DateTime ETD { get; set; }
        public DateTime ETA { get; set; }
        public required string PACK_TYPE { get; set; }
        public required string EXPEDITE_FLAG { get; set; }
        public string? PRODUCTNAME { get; set; }
        public string? BU { get; set; }
        public string? APPROVEID { get; set; }
    }

    public class OMS_3B2RTS_MAIN_Search
    {
        public string? ShipTo { get; set; }
        public string? PO { get; set; }
        public string? PN { get; set; }
        public string? Item { get; set; }
        public string? Line { get; set; }
    }
}
