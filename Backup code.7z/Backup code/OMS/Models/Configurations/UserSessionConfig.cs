﻿namespace OMS.Models.Configurations
{
    public record UserSessionInfo(string username, string IpAddress);
}
