﻿namespace OMS.Models.Configurations
{
    public record ApiAuthConfig(
        string? AuthType = null,
        string? ApiKey = null,
        string? Username = null,
        string? Password = null
    );

    public record ApiEndpointConfig(
        string BaseUrl,
        ApiAuthConfig? Auth = null,
        int TimeoutSeconds = 30
    );

    public class ApiConfig
    {
        public Dictionary<string, ApiEndpointConfig> Endpoints { get; set; } = new();
    }
}
