﻿namespace OMS.Models.Configurations
{
    public class DatabaseOptions
    {
        public required string OMSDB { get; set; }
    }
}
