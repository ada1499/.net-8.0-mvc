﻿namespace OMS.Models
{
    public class OMSViewModel<TData>
    {
        public required List<ColumnInfo> Columns { get; set; }
        public required List<TData> Data { get; set; }
    }

    public class ColumnInfo
    {
        public required string FieldName { get; set; }
        public required string DisplayName { get; set; }
        public string DataType { get; internal set; }
    }
}
