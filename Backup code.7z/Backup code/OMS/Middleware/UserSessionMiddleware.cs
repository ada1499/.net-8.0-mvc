﻿using OMS.Services.Session;

namespace OMS.Middleware
{
    public class UserSessionMiddleware
    {
        public readonly RequestDelegate _next;

        public UserSessionMiddleware(RequestDelegate next) => _next = next;

        public async Task InvokeAsync(HttpContext context)
        {
            if (context.User.Identity?.IsAuthenticated == true)
            {
                var sessionCache = context.RequestServices.GetRequiredService<IUserSessionCache>();
                var username = context.User.Identity.Name!;
                var currentIp = GetClientIp(context);
                var session = sessionCache.GetSession(username);

                //if(session is null || session.IpAddress != currentIp)
                //{
                //    await HandleInvalidSession(context, sessionCache, username);
                //    return;
                //}
            }

            await _next(context);
        }

        public static string GetClientIp(HttpContext context) =>
            context.Request.Headers["X-Forwarded-For"].FirstOrDefault() ??
            context.Connection.RemoteIpAddress?.ToString() ??
            "Unknown";

        private static async Task HandleInvalidSession(HttpContext context, IUserSessionCache cache, string username)
        {
            cache.RemoveSession(username);
            await context.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            context.Response.Redirect("/Account/Index");
        }
    }
}
