﻿// ---------------------------
// .NET Basic library
// ---------------------------
global using System;
global using System.Net;
global using System.Diagnostics;
global using System.Collections.Generic;

// ---------------------------
// Data processing and serialization
// ---------------------------
global using System.Data;
global using System.Text;
global using System.Text.Json;
global using Microsoft.Data.SqlClient;
global using Dapper;

// ---------------------------
// ASP.NET Core
// ---------------------------
global using Microsoft.AspNetCore.Mvc;
global using Microsoft.AspNetCore.HttpOverrides;
global using Microsoft.AspNetCore.Authentication;

// ---------------------------
// Security and authentication
// ---------------------------
global using System.Security.Claims;
global using Microsoft.AspNetCore.Authentication.Cookies;
global using Microsoft.AspNetCore.WebUtilities;

// ---------------------------
// Configuration and Infrastructure
// ---------------------------
global using Microsoft.Extensions.Caching.Memory;
global using Microsoft.Extensions.Options;
global using Microsoft.Extensions.Logging;

// ---------------------------
// Own project
// ---------------------------
global using OMS.Models;
global using OMS.Services;
global using OMS.Middleware;