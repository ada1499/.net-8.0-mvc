﻿export class Ajax {
    constructor(core) {
        this.core = core;
    }

    async fetchAjax(url, options) {
        try {
            const response = await fetch(url, options);
            if (!response.ok) throw new Error(await response.text());

            const contentType = response.headers.get('content-type');
            return contentType?.includes('application/json')
                ? await response.json()
                : null;
        } catch (error) {
            console.error("Error during fetch: ", error);
            throw new Error(error);
        }
    }
}