﻿export class Excel {
    constructor(core) {
        this.core = core;
    }

    uploadExcel() {
        const file = document.querySelector(this.core.config.selectors.excelFile).files[0];
        if (!file) return alert('Please upload the file!');

        this.core.state.originalData = {
            data: [...this.core.state.data],
            columns: [...this.core.state.columns]
        };

        const reader = new FileReader();

        reader.onload = (e) => {
            try {
                const wb = XLSX.read(e.target.result, { type: 'array', cellDates: true });
                const ws = wb.Sheets[wb.SheetNames[0]];
                const data = XLSX.utils.sheet_to_json(ws, { header: 1 });
                this.renderExcel(data);
                if (document.querySelector(this.core.config.selectors.buttons.update)) {
                    document.querySelector(this.core.config.selectors.buttons.update).style.display = 'none';
                }
                document.querySelector(this.core.config.selectors.confirmBtns).style.display = 'block';
            } catch (error) {
                console.error('Parse excel file failed: ', error);
                alert('Parse excel file failed. Please check the file format.');
            }
        };
        reader.readAsArrayBuffer(file);
    }

    renderExcel(data) {
        const [headers, ...rows] = data;

        this.core.state.columns = headers;
        this.core.state.data = rows.map((row, i) => {
            const obj = { F_ID: i + 1 };
            headers.forEach((h, idx) => {
                let cellValue = row[idx] ?? '';
                if (this.core.specialFields.dateFields.includes(h)) {
                    cellValue = XLSX.SSF.format('yyyy-MM-dd', cellValue);
                }
                obj[h] = cellValue;
            })
            return obj;
        });
        this.modules.pagination.renderPagination();
        this.modules.table.renderTable();
    }

    exportExcel() {
        if (!this.core.state.data.length) {
            alert('No data to export!');
            return;
        }

        const wsData = this.prepareWorksheetData();
        const ws = XLSX.utils.aoa_to_sheet(wsData);
        this.setExcelColumnFormats(ws);
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, this.core.config.fileName);
        XLSX.writeFile(wb, this.core.config.fileName + ".xlsx");
    }

    prepareWorksheetData() {
        const dateColIndices = this.getDateColumnIndices();

        return [
            this.core.state.columns,
            ...this.core.state.data.map(item =>
                this.core.state.columns.map((col, index) => {
                    const value = item[col];
                    return dateColIndices.has(index)
                        ? this.formatDateValue(value)
                        : value ?? '';
                })
            )
        ];
    }

    getDateColumnIndices() {
        return new Set(
            this.core.specialFields.dateFields
                .map(col => this.core.state.columns.indexOf(col))
                .filter(index => index !== -1)
        );
    }

    formatDateValue(value) {
        if (!value) return '';

        const date = new Date(value);
        return isNaN(date)
            ? value
            : XLSX.SSF.format('yyyy-mm-dd', date);
    }

    setExcelColumnFormats(ws) {
        const dateColIndices = this.getDateColumnIndices();
        ws['!cols'] = this.core.state.columns.map((_, index) =>
            dateColIndices.has(index)
                ? { width: 12, numFmt: 'yyyy-mm-dd' }
                : undefined
        );
    }
}