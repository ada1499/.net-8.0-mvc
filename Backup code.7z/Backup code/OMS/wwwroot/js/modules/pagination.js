﻿export class Pagination {
    constructor(core) {
        this.core = core;
    }

    renderPagination() {
        const { currentPage, totalPages } = this.core.config.selectors.pagination;
        
        const currentPageElement = document.querySelector(currentPage);
        if (currentPageElement) {
            currentPageElement.textContent = this.core.state.currentPage;
        }

        const totalPagesElement = document.querySelector(totalPages);
        if (totalPagesElement) {
            totalPagesElement.textContent = this.core.state.totalPages;
        }

        this.renderPageSelector();
    }

    renderPageSelector() {
        const selector = document.querySelector(this.core.config.selectors.pagination.pageSelect);
        if (!selector) return;
        
        selector.innerHTML = '';

        for (let i = 1; i <= this.core.state.totalPages; i++) {
            const option = document.createElement('option');
            option.value = i;
            option.textContent = i;
            option.selected = i === this.core.state.currentPage;
            selector.appendChild(option);
        }
    }

    goToPage(page) {
        const validPage = Math.max(1, Math.min(this.core.state.totalPages, page));
        if (this.core.state.currentPage !== validPage) {
            this.core.state.currentPage = validPage;
            this.renderPagination();
            this.modules.table.renderTable();
        }
    }

    changePage(delta) {
        this.goToPage(this.core.state.currentPage + delta);
    }
}