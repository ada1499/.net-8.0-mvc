﻿export class Core {
    constructor(config) {
        this.config = {
            selectors: {
                loading: '[data-role="loading"]',
                searchForm: '[data-role="search-form"]',
                checkbox: '[data-role="checkbox"]',
                selectAll: '[data-role="select-all"]',
                splitHead: '[data-role="split-head"]',
                tableBody: '[data-role="table-body"]',
                uploadForm: '[data-role="upload-form"]',
                excelFile: '[data-role="excel-file"]',
                confirmBtns: '[data-role="confirm-btns"]',
                pagination: {
                    prevPage: '[data-role="prev-page"]',
                    nextPage: '[data-role="next-page"]',
                    pageSelect:'[data-role="page-select"]',
                    currentPage: '[data-role="current-page"]',
                    totalPages: '[data-role="total-pages"]',
                },
                buttons: {
                    upload: '[data-role="upload-excel"]',
                    confirm: '[data-role="confirm-upload"]',
                    cancel: '[data-role="cancel-preview"]',
                    update: '[data-role="update"]',
                    exportExcel: '[data-role="export-excel"]'
                }
            },
            apiEndpoints: {
                search: '',
                update: '',
                uploadExcel: ''
            },
            fileName: config.fileName ?? '_Detail',
            enabledFlagsValues: config.enabledFlagsValues || [],
            flagColorMap: config.flagColorMap || {},
            isSplit: config.isSplit ?? false
        };

        this.state = {
            data: config.initialState?.data || {},
            columns: config.initialState?.columns || {},
            originalData: null,
            currentPage: 1,
            pageSize: 100,
            get totalPages() { return Math.ceil((this.data.length || 0) / this.pageSize); }
        };

        this.specialFields = {
            dropdownConfig: config.dropdownConfig || {},
            editableFields: config.editableFields || [],
            dateFields: config.dateFields || [],
            qtyFields: config.qtyFields || []
        };
    }

    parseEndpoints() {
        this.config.apiEndpoints = {
            search: document.querySelector(this.config.selectors.searchForm)?.dataset.action,
            uploadExcel: document.querySelector(this.config.selectors.uploadForm)?.dataset.action,
            update: document.querySelector(this.config.selectors.buttons.update)?.dataset.action
        };
    }
}