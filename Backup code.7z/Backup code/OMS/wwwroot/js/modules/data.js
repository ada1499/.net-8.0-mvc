﻿export class Data {
    constructor(core) {
        this.core = core;
    }

    async search(e) {
        this.modules.loading.showLoading();

        try {
            const formData = new FormData(e.target);
            const response = await this.modules.ajax.fetchAjax(this.core.config.apiEndpoints.search, { method: 'POST', body: formData });

            this.core.state.data = response;
            this.core.state.currentPage = 1;
            this.modules.pagination.renderPagination();
            this.modules.table.renderTable();
        } catch (error) {
            console.error("Search failed: ", error);
            throw new Error(error);
        } finally {
            this.modules.loading.hideLoading();
        }
    }

    async confirmUpload() {
        if (!confirm("Are you sure you want to upload the excel data?")) return;
        this.modules.loading.showLoading();

        try {
            const response = await this.modules.ajax.fetchAjax(this.core.config.apiEndpoints.uploadExcel, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(this.core.state.data)
            });

            const message = JSON.stringify(response[0].MESSAGE, null, 0) ?? 'Upload successful!';
            alert(message);

            await this.search({
                target: document.querySelector(this.core.config.selectors.searchForm),
                preventDefault: () => { }
            });
            if (document.querySelector(this.core.config.selectors.buttons.update)) {
                document.querySelector(this.core.config.selectors.buttons.update).style.display = 'block';
            }
            document.querySelector(this.core.config.selectors.confirmBtns).style.display = 'none';
        } catch (error) {
            console.error("Upload failed: ", error);
            throw new Error(error);
        } finally {
            this.modules.loading.hideLoading();
        }
    }

    async update() {
        if (!confirm("Are you sure you want to cimmit?")) return;
        this.modules.loading.showLoading();

        try {
            const updates = [...document.querySelectorAll('.rowCheckBox:checked')]
                .flatMap(checkbox => {
                    const row = checkbox.closest('tr');
                    if (!row?.dataset.original) return [];

                    const originalData = JSON.parse(row.dataset.original);
                    const currentData = Object.fromEntries(
                        [...row.querySelectorAll('[data-field]')].map(input => [
                            input.dataset.field,
                            input.value?.trim() || null
                        ])
                    );

                    return [{ ...originalData, ...currentData }];
                });

            if (!updates.length) return alert('No rows selected');

            const response = await this.modules.ajax.fetchAjax(this.core.config.apiEndpoints.update, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(updates)
            });

            const message = JSON.stringify(response[0].MESSAGE, null, 0) ?? 'Commit successful!';
            alert(message);

            await this.search({
                target: document.querySelector(this.core.config.selectors.searchForm),
                preventDefault: () => { }
            });
        } catch (error) {
            console.error("Commit failed: ", error);
            throw new Error(error);
        } finally {
            this.modules.loading.hideLoading();
        }
    }

    cancelPreview() {
        this.modules.loading.showLoading();
        this.core.state.columns = this.core.state.originalData.columns;
        this.core.state.data = this.core.state.originalData.data;
        this.modules.pagination.renderPagination();
        this.modules.table.renderTable();
        if (document.querySelector(this.core.config.selectors.buttons.update)) {
            document.querySelector(this.core.config.selectors.buttons.update).style.display = 'block';
        }
        document.querySelector(this.core.config.selectors.confirmBtns).style.display = 'none';
        this.modules.loading.hideLoading();
    }

    split(sourceRow) {
        const original = JSON.parse(sourceRow.dataset.original);
        const cloned = structuredClone(original);
        cloned.isCloned = true;

        const qtyFields = this.core.specialFields?.qtyFields;
        if (qtyFields?.length) {
            for (const field of qtyFields) {
                cloned[field] = 0;
            }
        }

        sourceRow.insertAdjacentHTML('afterend', this.modules.table.generateRowHtml(cloned));
    }
}