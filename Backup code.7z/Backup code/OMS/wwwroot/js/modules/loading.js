﻿export class Loading {
    constructor(core) {
        this.core = core;
        this.loadingElement = document.querySelector(core.config.selectors.loading);
    }

    showLoading() {
        if (this.loadingElement) {
            this.loadingElement.classList.add('show');
        }

        document.querySelectorAll('button').forEach(btn => {
            btn.setAttribute('data-previous-state', btn.disabled);
            btn.disabled = true;
        });
    }

    hideLoading() {
        if (this.loadingElement) {
            this.loadingElement.classList.remove('show');
        }

        document.querySelectorAll('button').forEach(btn => {
            const previousState = btn.dataset.previousState;
            btn.disabled = previousState === 'true';
            btn.removeAttribute('data-previous-state');
        });
    }
}