﻿export class Table {
    constructor(core) {
        this.core = core;
    }

    renderTable() {
        const hasFlagColumn = this.core.state.columns.some(col => col === 'FLAG');
        if (hasFlagColumn) {
            document.querySelector(this.core.config.selectors.checkbox).style.display = 'table-cell';
        }
        if (this.core.config.isSplit) {
            document.querySelector(this.core.config.selectors.splitHead).style.display = 'table-cell';
        }

        const start = (this.core.state.currentPage - 1) * this.core.state.pageSize;
        const pageData = this.core.state.data.slice(start, start + this.core.state.pageSize);

        const tableBody = document.querySelector(this.core.config.selectors.tableBody);
        if (tableBody) {
            tableBody.innerHTML = pageData.map(row => this.generateRowHtml(row)).join('');
        }
    }

    generateRowHtml(row) {
        const enabledFlags = this.core.config.enabledFlagsValues || [];
        const isEnabled = enabledFlags.includes(row.FLAG);
        const isCloned = row.isCloned ?? false;
        return `
            <tr data-original='${JSON.stringify(row)}'>
                ${'FLAG' in row ? `<td><input type="checkBox" class="rowCheckBox" ${!isEnabled ? 'disabled' : ''} /></td>` : ''}
                ${
                    this.core.config.isSplit
                        ? ('FLAG' in row && isEnabled
                            ? isCloned
                                ? `<td style="text-align: center;"><span data-action="delete" role="button" tabindex="0" style="color: red; font-size: 0.8em; font-weight: bold;">❌</span></td>`
                                : `<td style="text-align: center;"><span data-action="split" role="button" tabindex="0" style="color: #159045; font-weight: bold;">✚</span></td>`
                            : `<td></td>`)
                        : ''
                }
                ${this.core.state.columns.map(field => this.generateCell(field, row[field], isEnabled)).join('')}
            </tr>`;
    }

    generateCell(field, value, isEnabled) {
        if (field === 'FLAG') {
            const flagClass = this.core.config.flagColorMap[value] ?? 'status-grey';
            return `<td style="text-align: center;"><span class="status-indicator ${flagClass}"></span></td>`
        }

        if (isEnabled) {
            if (this.core.specialFields.dropdownConfig[field]) {
                return `<td>${this.createDropdown(field, value)}</td>`;
            }
            if (this.core.specialFields.editableFields.includes(field)) {
                return `<td><input type="text" class="editable" data-field="${field}" value="${value ?? ''}"} /></td>`;
            }
        }

        if (this.core.specialFields.dateFields.includes(field)) {
            const formattedDate = value?.split('T')[0] ?? '';
            return `<td>${formattedDate}</td>`;
        }

        return `<td>${value ?? ''}</td>`;
    }

    createDropdown(fieldName, selectedValue) {
        const options = this.core.specialFields.dropdownConfig[fieldName].map(opt =>
            `<option ${opt === selectedValue ? 'selected' : ''}>${opt}</option>`
        ).join('');
        return `<select data-field="${fieldName}">${options}</select>`;
    }
}