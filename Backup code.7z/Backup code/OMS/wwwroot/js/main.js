﻿import { Core } from './modules/core.js';
import { Loading } from './modules/loading.js';
import { Ajax } from './modules/ajax.js';
import { Data } from './modules/data.js';
import { Table } from './modules/table.js';
import { Pagination } from './modules/pagination.js';
import { Event } from './modules/event.js';
import { Excel } from './modules/excel.js';

export class Main {
    constructor(config) {
        this.core = new Core(config);
        this.modules = {
            loading: new Loading(this.core),
            ajax: new Ajax(this.core),
            data: new Data(this.core),
            table: new Table(this.core),
            pagination: new Pagination(this.core),
            event: new Event(this.core),
            excel: new Excel(this.core)
        };

        Object.values(this.modules).forEach(module => {
            module.modules = this.modules;
        });
    }

    initialize() {
        this.modules.pagination.renderPagination();
        this.modules.table.renderTable();
        this.modules.event.bindEvents();
        this.core.parseEndpoints();
    }
}

if (typeof window !== 'undefined') {
    window.Main = Main;
}