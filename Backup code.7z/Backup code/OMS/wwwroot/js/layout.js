﻿document.querySelectorAll('.nav-link[data-url]').forEach(link => {
    link.addEventListener('click', function (e) {
        e.preventDefault();
        const url = this.dataset.url;
        loadContent(url);
    });
});

async function loadContent(url) {
    const container = document.getElementById('mainContent');

    try {
        const response = await fetch(url);
        if (!response.ok) throw new Error(await response.status);
        const html = await response.text();

        const parser = new DOMParser();
        const doc = parser.parseFromString(html, 'text/html');
        const scripts = Array.from(doc.querySelectorAll('script'));
        container.innerHTML = doc.body.innerHTML;

        scripts.forEach(script => {
            const newScript = document.createElement('script');
            if (script.type) newScript.type = script.type;
            if (script.src) {
                newScript.src = script.src;
            } else {
                newScript.textContent = script.textContent;
            }
            document.body.appendChild(newScript).parentNode.removeChild(newScript);
        });
    } catch (error) {
        container.innerHTML = `<div class="alert alert-danger">${error.message}</div>`;
    }
}