﻿class SidebarAccordion {
    constructor(selector = '#sidebar') {
        this.sidebar = document.querySelector(selector);
        this.groupSelector = '.menu-group';
        this.collapseSelector = '.collapse';
        this.init();
    }

    init() {
        this.sidebar?.addEventListener('click', this.handleGroupClick.bind(this));
        this.initCollapseEvents();
    }

    handleGroupClick(event) {
        const target = event.target.closest(this.groupSelector);
        if (!target) return;

        const currentCollapse = target.querySelector(this.collapseSelector);
        this.closeOthers(currentCollapse);
    }

    closeOthers(currentCollapse) {
        const allCollapses = [...this.sidebar.querySelectorAll(this.collapseSelector)];
            
        allCollapses.forEach(collapse => {
            if (collapse !== currentCollapse && this.isCollapseOpen(collapse)) {
                bootstrap.Collapse.getInstance(collapse)?.hide();
            }
        });
    }

    isCollapseOpen(collapseElement) {
        return collapseElement.classList.contains('show');
    }

    initCollapseEvents() {
        this.sidebar?.querySelectorAll(this.collapseSelector).forEach(collapse => {
            collapse.addEventListener('show.bs.collapse', () => {
                this.closeOthers(collapse);
            });
        });
    }
}

document.addEventListener('DOMContentLoaded', () => {
    new SidebarAccordion();
});