﻿using OMS.Models.Api;

namespace OMS.Services.Api.Builders
{
    public sealed class SapRequestBuilder
    {
        private string? _funcName;
        private readonly Dictionary<string, string> _inValue = new();
        private readonly Dictionary<string, Dictionary<string, string>> _inTable = new();

        public SapRequestBuilder WithFunction(string funcName)
        {
            _funcName = funcName;
            return this;
        }

        public SapRequestBuilder AddInputValue(string key, string value)
        {
            _inValue[key] = value;
            return this;
        }

        public SapRequestBuilder AddInputTable(string table, Dictionary<string, string> columns)
        {
            _inTable[table] = new(columns);
            return this;
        }

        public ApiSapRequest build() => new(
            _funcName ?? throw new ArgumentNullException(nameof(_funcName)),
            new(_inValue, _inTable)
        );
    }
}
