﻿using OMS.Models.Configurations;

namespace OMS.Services.Database
{
    public class DbService(IOptions<DatabaseOptions> options, IMemoryCache cache) : IDbService, IAsyncDisposable
    {
        private readonly DbInfrastructure _infra = new(options.Value.OMSDB);
        private readonly DbMetadata _metadata = new(cache);

        public async Task<OMSViewModel<T>> GetModelDataAsync<T>(string command, object? parameters = null, bool isStoredProcedure = false) where T : class
        {
            var data = await QueryAsync<T>(command, parameters, isStoredProcedure);
            return new OMSViewModel<T>
            {
                Columns = _metadata.GetColumnMetadata<T>(),
                Data = data.ToList()
            };
        }

        public async Task<IEnumerable<IDictionary<string, object>>> ExecuteDynamicAsync(string command, object? parameters = null, bool isStoredProcedure = false)
        {
            var result = await QueryAsync<dynamic>(command, parameters, isStoredProcedure);
            return result.Select(row => (IDictionary<string, object>)row);
        }

        public async Task<IEnumerable<T>> QueryAsync<T>(string command, object? parameters = null, bool isStoredProcedure = false)
            => await _infra.UseConnectionAsync(conn =>
                conn.QueryAsync<T>(_infra.CreateCommand(command, parameters, isStoredProcedure)));

        public async Task<int> ExecuteAsync(string command, object? parameters = null, bool isStoredProcedure = false)
            => await _infra.UseConnectionAsync(conn =>
                conn.ExecuteAsync(_infra.CreateCommand(command, parameters, isStoredProcedure)));

        public ValueTask DisposeAsync()
        {
            GC.SuppressFinalize(this);
            return ValueTask.CompletedTask;
        }
    }
}
