﻿using OMS.Models.Configurations;
using OMS.Services.Database;

namespace OMS.Services
{
    public interface IScopedService { }
    public interface ITransientService { }
    public interface ISingletonService { }
    public static class ServiceCollectionExtensions
    {
        public static IServiceCollection AddAllServices(this IServiceCollection services, IConfiguration configuration)
        {
            services.Scan(scan => scan
                .FromAssembliesOf(typeof(IDbService))
                .AddClasses(classes => classes.AssignableTo<IScopedService>())
                    .AsSelf()
                    .AsImplementedInterfaces()
                    .WithScopedLifetime()
                .AddClasses(classes => classes.AssignableTo<ITransientService>())
                    .AsSelf()
                    .AsImplementedInterfaces()
                    .WithTransientLifetime()
                .AddClasses(classes => classes.AssignableTo<ISingletonService>())
                    .AsSelf()
                    .AsImplementedInterfaces()
                    .WithSingletonLifetime());

            services
                .AddMemoryCache(options =>
                {
                    options.SizeLimit = 1024;
                })
                .AddHttpClient()
                .Configure<DatabaseOptions>(configuration.GetSection("ConnectionStrings"))
                .Configure<ApiConfig>(configuration.GetSection("ApiConfig"))
                .Configure<ForwardedHeadersOptions>(options =>
                {
                    options.ForwardedHeaders = ForwardedHeaders.XForwardedFor | ForwardedHeaders.XForwardedProto;
                    options.KnownNetworks.Clear();
                    options.KnownProxies.Clear();
                })
                .AddScoped<AllServices>();

            return services;
        }
    }
}
