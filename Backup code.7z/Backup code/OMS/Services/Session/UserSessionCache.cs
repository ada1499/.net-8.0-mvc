﻿using OMS.Models.Configurations;

namespace OMS.Services.Session
{
    public class UserSessionCache : IUserSessionCache, IScopedService
    {
        private readonly IMemoryCache _cache;
        private readonly TimeSpan _slidingExpiration = TimeSpan.FromMinutes(30);

        public UserSessionCache(IMemoryCache cache) => _cache = cache;

        public void UpdateSession(string username, string ipAddress)
        {
            _cache.Set(username, new UserSessionInfo(username, ipAddress), new MemoryCacheEntryOptions
            {
                SlidingExpiration = _slidingExpiration,
                Size = 1
            });
        }

        public UserSessionInfo? GetSession(string username) => _cache.Get<UserSessionInfo>(username);

        public void RemoveSession(string username) => _cache.Remove(username);
    }
}
