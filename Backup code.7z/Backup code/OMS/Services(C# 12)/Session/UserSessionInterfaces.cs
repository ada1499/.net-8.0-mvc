﻿namespace OMS.Services.Session
{
    public interface IUserSessionCache
    {
        void UpdateSession(string username, string ipAddress);
        UserSessionInfo? GetSession(string username);
        void RemoveSession(string username);
    }
}
