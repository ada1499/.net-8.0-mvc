﻿namespace OMS.Services.Session
{
    public record UserSessionInfo(string username, string IpAddress);
}
