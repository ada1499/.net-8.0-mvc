﻿using OMS.Services.Api;
using OMS.Services.Database;
using OMS.Services.SAP;
using OMS.Services.Session;

namespace OMS.Services
{
    public sealed class AllServices(IServiceProvider serviceProvider)
    {
        public IDbService DbService => serviceProvider.GetRequiredService<IDbService>();
        public IUserSessionCache UserSessionCache => serviceProvider.GetRequiredService<IUserSessionCache>();
        public IApiService ApiService => serviceProvider.GetRequiredService<IApiService>();
        public IRfcService RfcService => serviceProvider.GetRequiredService<IRfcService>();
    }
}
