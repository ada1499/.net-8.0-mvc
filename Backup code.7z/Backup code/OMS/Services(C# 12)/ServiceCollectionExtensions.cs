﻿using OMS.Services.Api;
using OMS.Services.Database;
using OMS.Services.SAP;

namespace OMS.Services
{
    public interface IScopedService { }
    public interface ITransientService { }
    public interface ISingletonService { }
    public static class ServiceCollectionExtensions
    {
        public static IServiceCollection AddAllServices(this IServiceCollection services, IConfiguration configuration)
        {
            services.Scan(scan => scan
                .FromAssembliesOf(typeof(IDbService), typeof(IRfcService))
                .AddClasses(classes => classes.AssignableTo<IScopedService>())
                    .AsSelf()
                    .AsImplementedInterfaces()
                    .WithScopedLifetime()
                .AddClasses(classes => classes.AssignableTo<ITransientService>())
                    .AsSelf()
                    .AsImplementedInterfaces()
                    .WithTransientLifetime()
                .AddClasses(classes => classes.AssignableTo<ISingletonService>())
                    .AsSelf()
                    .AsImplementedInterfaces()
                    .WithSingletonLifetime());

            services
                .AddMemoryCache(options =>
                {
                    options.SizeLimit = 1024;
                })
                .AddHttpClient()
                .Configure<DatabaseOptions>(configuration.GetSection("ConnectionStrings"))
                .Configure<ApiConfig>(configuration.GetSection("ApiConfig"))
                .Configure<RfcOptions>(configuration.GetSection("SapRfc"))
                .Configure<ForwardedHeadersOptions>(options =>
                {
                    options.ForwardedHeaders = ForwardedHeaders.XForwardedFor | ForwardedHeaders.XForwardedProto;
                    options.KnownNetworks.Clear();
                    options.KnownProxies.Clear();
                })
                .AddSingleton<IRfcClient>(provider 
                    => new RfcClient(provider.GetRequiredService<IOptions<RfcConfiguration>>(), provider.GetRequiredService<ILogger<RfcClient>>()))
                .AddScoped<IRfcService, RfcService>()
                .AddScoped<AllServices>();

            return services;
        }
    }
}
