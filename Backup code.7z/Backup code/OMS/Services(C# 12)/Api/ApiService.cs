﻿namespace OMS.Services.Api
{
    public class ApiService(IHttpClientFactory httpClientFactory, IOptions<ApiConfig> config) : IApiService
    {
        public async Task<TResponse> SendAsync<TResponse>(
            string endpointName,
            HttpMethod method,
            object? requestData = null,
            Dictionary<string, string>? parameters = null,
            CancellationToken ct = default)
        {
            if (!config.Value.Endpoints.TryGetValue(endpointName, out var endpoint))
                throw new ArgumentException($"Endpoint {endpointName} not configured");

            using var client = CreateHttpClient(endpoint);
            var request = CreatedResultMessage(endpoint, method, requestData, parameters);

            using var response = await client.SendAsync(request);
            return await HandleResponse<TResponse>(response);
        }

        private HttpClient CreateHttpClient(ApiEndpointConfig config)
        {
            var client = httpClientFactory.CreateClient(config.Name);
            client.Timeout = TimeSpan.FromSeconds(config.TimeoutSeconds);
            return client;
        }

        public static HttpRequestMessage CreatedResultMessage(
            ApiEndpointConfig config,
            HttpMethod method,
            object? requestData = null,
            Dictionary<string, string>? parameters = null)
        {
            var url = BuildUrl(config.BaseUrl, parameters);
            var request = new HttpRequestMessage(method, url);

            if (requestData != null)
            {
                request.Content = new StringContent(JsonSerializer.Serialize(requestData), Encoding.UTF8, "application/json");
            }

            AddAuthentication(request, config.Auth);
            return request;
        }

        private static string BuildUrl(string baseUrl, Dictionary<string, string>? parameters)
            => parameters?.Count > 0
                ? QueryHelpers.AddQueryString(baseUrl, parameters!)
                : baseUrl;

        private static void AddAuthentication(HttpRequestMessage request, ApiAuthConfig authConfig)
        {
            request.Headers.Authorization = authConfig.AuthType switch
            {
                "Basic" => new(
                    "Basic",
                    Convert.ToBase64String(Encoding.ASCII.GetBytes($"{authConfig.Username}:{authConfig.Password}"))),
                "Bearer" => new("Bearer", authConfig.ApiKey),
                "ApiKey" => new("ApiKey", authConfig.ApiKey),
                _ => null
            };
        }

        private static async Task<T> HandleResponse<T>(HttpResponseMessage response)
        {
            var content = await response.Content.ReadAsStringAsync();

            if (!response.IsSuccessStatusCode)
                throw new ApiException($"API request failed: {response.StatusCode}", response.StatusCode, content);

            try
            {
                return JsonSerializer.Deserialize<T>(content)
                    ?? throw new InvalidOperationException("Null response content");
            }
            catch (JsonException ex)
            {
                throw new ApiException($"Failed to deserialize response: {ex.Message}", response.StatusCode, content);
            }
        }
    }
}
