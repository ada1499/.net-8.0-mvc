﻿namespace OMS.Services.Api
{
    public interface IApiService : ITransientService
    {
        Task<TResponse> SendAsync<TResponse>(
            string endpointName,
            HttpMethod method,
            object? requestData = null,
            Dictionary<string, string>? parameters = null,
            CancellationToken ct = default
        );
    }
}
