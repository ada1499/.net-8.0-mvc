﻿namespace OMS.Services.Api
{
    public record ApiAuthConfig(
        string AuthType,
        string? ApiKey = null,
        string? Username = null,
        string? Password = null
    );

    public record ApiEndpointConfig(
        string Name,
        string BaseUrl,
        ApiAuthConfig Auth,
        int TimeoutSeconds = 30
    );

    public class ApiConfig
    {
        public Dictionary<string, ApiEndpointConfig> Endpoints { get; set; } = new();
    }
}
