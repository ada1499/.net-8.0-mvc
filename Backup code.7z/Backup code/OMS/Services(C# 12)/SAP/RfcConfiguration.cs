﻿namespace OMS.Services.SAP
{
    public class RfcConfiguration
    {
        public required string Name { get; set; }
        public required string User { get; set; }
        public required string Password { get; set; }
        public required string Client { get; set; }
        public required string Language { get; set; } = "EN";
        public required string AppServerHost { get; set; }
        public required string SystemNumber { get; set; } = "00";
        public int PoolSize { get; set; } = 20;
        public TimeSpan IdleTimeout { get; set; } = TimeSpan.FromMinutes(15);
    }

    public class RfcOptions
    {
        public Dictionary<string, RfcConfiguration> Configurations { get; set; } = new();
    }
}
