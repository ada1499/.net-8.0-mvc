﻿using SAP.Middleware.Connector;
using System.Collections.Concurrent;

namespace OMS.Services.SAP
{
    internal sealed class RfcConnectionPool : IDisposable
    {
        private readonly ConcurrentBag<RfcDestination> _connections = new();
        private readonly RfcConfiguration _config;

        public RfcConnectionPool(IOptions<RfcConfiguration> config)
        {
            _config = config.Value;
            InitializePool();
        }

        private void InitializePool()
        {
            for (int i = 0; i < _config.PoolSize; i++)
            {
                _connections.Add(CreateDestination());
            }
        }

        private RfcDestination CreateDestination()
        {
            var testParam = new RfcConfigParameters();
            testParam[RfcConfigParameters.Name] = "Test";
            testParam[RfcConfigParameters.Name] = _config.Name;

            var parameters = new RfcConfigParameters
            {
                { RfcConfigParameters.Name, _config.Name },
                { RfcConfigParameters.User, _config.User },
                { RfcConfigParameters.Password, _config.Password },
                { RfcConfigParameters.Client, _config.Client },
                { RfcConfigParameters.Language, _config.Language },
                { RfcConfigParameters.AppServerHost, _config.AppServerHost },
                { RfcConfigParameters.SystemNumber, _config.SystemNumber },
                { RfcConfigParameters.PoolIdleTimeout, _config.IdleTimeout.TotalSeconds.ToString() }
            };

            return RfcDestinationManager.GetDestination(parameters);
        }

        public async Task<RfcDestination> GetConnectionAsync()
        {
            while (true)
            {
                if (_connections.TryTake(out var conn))
                {
                    return conn;
                }
                await Task.Delay(10);
            }
        }

        public void ReturnConnection(RfcDestination connection)
        {
            _connections.Add(connection);
        }

        public void Dispose()
        {
            _connections.Clear();
        }
    }

    internal sealed class RfcClient : IRfcClient, IDisposable
    {
        private readonly RfcConnectionPool _pool;
        private readonly ILogger _logger;

        public RfcClient(IOptions<RfcConfiguration> config, ILogger<RfcClient> logger)
        {
            _logger = logger;
            _pool = new RfcConnectionPool(config);
        }

        public async Task<RfcResponse> CallRfcAsync(
            string funcName,
            Dictionary<string, object> parameters,
            CancellationToken ct = default)
        {
            var conn = await _pool.GetConnectionAsync();
            try
            {
                var repo = conn.Repository;
                var function = repo.CreateFunction(funcName);

                foreach (var param in parameters)
                    function.SetValue(param.Key, param.Value);

                function.Invoke(conn);
                var result = ProcessFunctionResult(function);
                return new RfcResponse(true, result);
            }
            catch(Exception ex)
            {
                _logger.LogError(ex, "RFC call failed for {Function}", funcName);
                return new RfcResponse(false, null, ex.Message);
            }
            finally
            {
                _pool.ReturnConnection(conn);
            }
        }

        private static Dictionary<string, object> ProcessFunctionResult(IRfcFunction function)
        {
            var result = new Dictionary<string, object>();

            //// Process output parameters
            //foreach (var param in function.GetParameters()
            //    .Where(p => p.Direction != RfcDirection.IMPORT))
            //{
            //    result[param.Name] = function.GetValue(param.Name);
            //}

            //// Process output tables
            //foreach (var table in function.GetTables())
            //{
            //    var tableData = new List<Dictionary<string, object>>();
            //    for (int i = 0; i < table.RowCount; i++)
            //    {
            //        table.CurrentIndex = i;
            //        var row = new Dictionary<string, object>();
            //        foreach (var field in table.Fields)
            //        {
            //            row[field.Name] = table.GetValue(field.Name);
            //        }
            //        tableData.Add(row);
            //    }
            //    result[table.Name] = tableData;
            //}

            return result;
        }

        public void Dispose() => _pool.Dispose();
    }
}
