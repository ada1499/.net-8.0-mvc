﻿namespace OMS.Services.SAP
{
    public interface IRfcClient : ISingletonService
    {
        Task<RfcResponse> CallRfcAsync(
           string funcName,
           Dictionary<string, object> parameters,
           CancellationToken ct = default);
    }

    public interface IRfcService : IScopedService
    {
        Task<RfcResponse> GetDataAsync(string funcName, object? request = null);
    }
}
