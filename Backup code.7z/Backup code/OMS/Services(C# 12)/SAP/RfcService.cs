﻿namespace OMS.Services.SAP
{
    internal sealed class RfcService : IRfcService
    {
        private readonly IRfcClient _client;

        public RfcService(IRfcClient client) => _client = client;

        public async Task<RfcResponse> GetDataAsync(string funcName, object? request = null)
        {
            var paramters = new Dictionary<string, object>
            {
                ["PLANT"] = "VJGS"
            };

            return await _client.CallRfcAsync(funcName, paramters);
        }
    }
}
