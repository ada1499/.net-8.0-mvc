﻿using System.ComponentModel.DataAnnotations;

namespace OMS.Services.SAP
{
    public record RfcResponse(bool Success, object? Data, string? Error = null);
    public record RfcRequest(string FuncName, Dictionary<string, object> Parameters);

    public class RfcTable
    {
        [Required] public required string Name { get; init; }
        [Required] public required List<Dictionary<string, object>> Rows { get; init; }
    }
}
