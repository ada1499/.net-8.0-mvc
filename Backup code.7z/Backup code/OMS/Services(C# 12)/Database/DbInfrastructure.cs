﻿namespace OMS.Services.Database
{
    public class DbInfrastructure
    {
        private readonly string _connString;

        public DbInfrastructure(string connectionString)
            => _connString = connectionString;

        public async ValueTask<T> UseConnectionAsync<T>(Func<SqlConnection, Task<T>> execute, CancellationToken ct = default)
        {
            await using var conn = new SqlConnection(_connString);
            await conn.OpenAsync(ct);
            return await execute(conn);
        }

        public CommandDefinition CreateCommand(string command, object? parameters, bool isStoredProcedure, CancellationToken ct = default)
        {
            ArgumentException.ThrowIfNullOrEmpty(command, "Command text cannot be empty");

            return new(
                command,
                DbParametersBuilder.GetDynamicParameters(parameters),
                commandType: isStoredProcedure ? CommandType.StoredProcedure : CommandType.Text,
                cancellationToken: ct);
        }
    }
}
