﻿namespace OMS.Services.Database
{
    public class DbMetadata(IMemoryCache cache)
    {
        private static readonly MemoryCacheEntryOptions _cacheEntryOptions = new()
        {
            SlidingExpiration = TimeSpan.FromMinutes(15),
            Size = 1,
            Priority = CacheItemPriority.Low
        };

        public List<ColumnInfo> GetColumnMetadata<T>() where T : class
            => cache.GetOrCreate(typeof(T), entry =>
            {
                entry.SetOptions(_cacheEntryOptions);
                return typeof(T).GetProperties().Select(p => new ColumnInfo
                {
                    FieldName = p.Name,
                    DisplayName = p.Name,
                    DataType = p.PropertyType.Name
                }).ToList();
            })!;
    }
}
