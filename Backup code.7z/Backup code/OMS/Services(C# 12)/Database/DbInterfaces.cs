﻿namespace OMS.Services.Database
{
    public interface IDbService : IScopedService
    {
        Task<OMSViewModel<T>> GetModelDataAsync<T>(string command, object? parameters = null, bool isStoredProcedure = false) where T : class;
        Task<IEnumerable<IDictionary<string, object>>> ExecuteDynamicAsync(string command, object? parameters = null, bool isStoredProcedure = false);
        Task<IEnumerable<T>> QueryAsync<T>(string command, object? parameters = null, bool isStoredProcedure = false);
        Task<int> ExecuteAsync(string command, object? parameters = null, bool isStoredProcedure = false);
    }
}
