﻿namespace OMS.Services.Database
{
    public class DbParametersBuilder
    {
        public static DynamicParameters GetDynamicParameters(object? parameters = null)
            => parameters switch
            {
                null => new(),
                DynamicParameters dp => dp,
                SqlParameter[] sqlParams => ConvertSqlParameters(sqlParams),
                IEnumerable<SqlParameter> sqlParams => ConvertSqlParameters(sqlParams),
                _ => new DynamicParameters(parameters)
            };

        private static DynamicParameters ConvertSqlParameters(IEnumerable<SqlParameter> sqlParameters)
        {
            var dynamicParams = new DynamicParameters();
            foreach (var p in sqlParameters ?? [])
                dynamicParams.Add(p.ParameterName, p.Value, p.DbType, p.Direction);
            return dynamicParams;
        }
    }
}
