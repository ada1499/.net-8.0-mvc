﻿namespace OMS.Services.Database
{
    public class DatabaseOptions
    {
        public required string OMSDB { get; set; }
    }
}
