var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services
    .AddControllersWithViews()
        // Disable camel jump naming.
        .AddJsonOptions(options => options.JsonSerializerOptions.PropertyNamingPolicy = null)
        .AddRazorOptions(options =>
        {
            options.ViewLocationFormats.Add("/Views/OMS/{1}/{0}.cshtml");
            options.ViewLocationFormats.Add("/Views/OMS/{0}.cshtml");
        });

builder.Services.AddAllServices(builder.Configuration);

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app
    .UseForwardedHeaders()
    .UseHttpsRedirection()
    .UseStaticFiles()
    .UseRouting()
    .UseAuthentication()
    .UseAuthorization()
    .UseMiddleware<UserSessionMiddleware>();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Account}/{action=Index}/{id?}");

app.Run();
