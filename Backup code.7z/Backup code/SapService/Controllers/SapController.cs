﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Web.Http;
using SAP.Middleware.Connector;
using Newtonsoft.Json;
using System.Text.RegularExpressions;
using SapService.Models;

namespace SapService.Controllers
{
    public class SapRequest
    {
        public string FuncName { get; set; }
        public Dictionary<string, Dictionary<string, object>> Parameters { get; set; }
    }

    public class SapController : ApiController
    {
        [HttpPost]
        public IHttpActionResult ExcuteRfc([FromBody] SapRequest request)
        {
            try
            {
                var result = InvokeSapRfc(request.FuncName, request.Parameters);
                return Ok(new { Success = true, Data = result });
            }
            catch (Exception ex)
            {
                return InternalServerError(ex);
            }
        }

        private string InvokeSapRfc(string funcName, Dictionary<string, Dictionary<string, object>> parameters)
        {
            RfcConfigParameters config = new RfcConfigParameters()
            {
                { RfcConfigParameters.Name, "ZCSD_NSBG_0037" },
                { RfcConfigParameters.User, "NSGBG" },
                { RfcConfigParameters.Password, "MESEDICU" },
                { RfcConfigParameters.Client, "860" },
                { RfcConfigParameters.Language, "EN" },
                { RfcConfigParameters.AppServerHost, "10.134.167.159" },
                { RfcConfigParameters.SystemNumber, "00" },
                { RfcConfigParameters.SystemID, "3600" }
            };

            RfcDestination dest = RfcDestinationManager.GetDestination(config);
            RfcRepository repo = dest.Repository;
            IRfcFunction function = repo.CreateFunction(funcName);

            foreach (var param in parameters)
            {
                var tableName = param.Key;
                var fields = param.Value;
                IRfcTable table = function.GetTable(tableName);
                table.Append();

                foreach (var field in fields)
                {
                    table.SetValue(field.Key, field.Value.ToString());
                }
            }

            function.Invoke(dest);
            var otbs = function.GetTable("O_TAB");
            List<Dictionary<string, string>> jsonList = new List<Dictionary<string, string>>();
            foreach (var otb in otbs)
            {
                var data = otb.ToString();
                var matches = Regex.Matches(data, @"FIELD (\w+)=([^ ]*)");

                var dict = matches.Cast<Match>().ToDictionary(
                    m => m.Groups[1].Value,
                    m => m.Groups[2].Value
                );
                jsonList.Add(dict);
            }

            var json = JsonConvert.SerializeObject(jsonList);
            return json;
        }
    }
}