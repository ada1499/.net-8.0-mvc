﻿using SAP.Middleware.Connector;
using SapService.Models;
using System;
using System.Linq;

namespace SapService.Services
{
    internal sealed class RfcInfrastructure
    {
        public IRfcFunction CreateFunctionWithRetry(RfcDestination dest, string funcName, int retryCount = 2)
        {
            while (retryCount-- >= 0)
            {
                try
                {
                    return dest.Repository.CreateFunction(funcName);
                }
                catch (RfcFunctionNotFoundException) when (retryCount > 0)
                {
                    System.Threading.Thread.Sleep(100);
                }
            }
            throw new InvalidOperationException($"Create rfc function({funcName}) failed");
        }

        public void SetInputParameters(IRfcFunction function, InputParams input)
        {
            foreach (var value in input.InValue)
            {
                function.SetValue(value.Key, value.Value);
            }

            foreach (var table in input.Table)
            {
                IRfcTable rfcTable = function.GetTable(table.Key);
                rfcTable.Append();

                foreach (var field in table.Value)
                {
                    rfcTable.SetValue(field.Key, field.Value.ToString());
                }
            }
        }

        public RfcResponse GetOutputResults(IRfcFunction function)
        {
            var response = new RfcResponse();
            var parameters = function.Cast<IRfcParameter>().Select(p => (
                param: p,
                meta: p.Metadata,
                name: p.Metadata.Name
            ));

            foreach (var (param, meta, name) in parameters)
            {
                if (meta.Direction == RfcDirection.TABLES)
                {
                    var tableData = param.GetTable()
                        .Cast<IRfcStructure>()
                        .Select(row => Enumerable.Range(0, row.Metadata.FieldCount)
                            .ToDictionary(i => row.GetElementMetadata(i).Name, i => row.GetString(i)))
                        .ToList();

                    response.OutputTables[name] = tableData;
                }
                else
                {
                    response.OutputValues[name] = param.GetString();
                }
            }

            return response;
        }

        public void ReleaseFunction(IRfcFunction function)
            => (function as IDisposable)?.Dispose();
    }
}