﻿using SAP.Middleware.Connector;
using System.Collections.Concurrent;
using System.Threading.Tasks;

namespace SapService.Services
{
    internal sealed class RfcConnectionPool : IRfcConnectionPool
    {
        private readonly IRfcConfigReader _configReader;
        private readonly ConcurrentDictionary<string, RfcDestination> _destinationCache;
        private readonly object _configLock = new object();
        private DynamicDestinationConfiguration _dynamicDestination;
        private bool _isConfigRegistered;

        public RfcConnectionPool(IRfcConfigReader configReader)
        {
            _configReader = configReader;
            _destinationCache = new ConcurrentDictionary<string, RfcDestination>();
            RegisterGlobalConfiguration();
        }

        private void RegisterGlobalConfiguration()
        {
            lock (_configLock)
            {
                if (_isConfigRegistered) return;

                _dynamicDestination = new DynamicDestinationConfiguration(_configReader);
                RfcDestinationManager.RegisterDestinationConfiguration(_dynamicDestination);
                _isConfigRegistered = true;
            }
        }

        public Task<RfcDestination> GetDestinationAsync(string funcName)
            => Task.FromResult(_destinationCache.GetOrAdd(funcName, name =>
            {
                return RfcDestinationManager.GetDestination(name);
            }));

        public void Dispose()
        {
            lock (_configLock)
            {
                if (!_isConfigRegistered) return;

                RfcDestinationManager.UnregisterDestinationConfiguration(_dynamicDestination);
                _isConfigRegistered = false;
            }
            _destinationCache.Clear();
        }

        private class DynamicDestinationConfiguration : IDestinationConfiguration
        {
            private readonly IRfcConfigReader _configReader;

            public DynamicDestinationConfiguration(IRfcConfigReader configReader)
                => _configReader = configReader;

            public RfcConfigParameters GetParameters(string destinationName)
                => _configReader.GetConfig(destinationName)?.ToRfcParameters();

            public bool ChangeEventsSupported() => false;
            public event RfcDestinationManager.ConfigurationChangeHandler ConfigurationChanged;
        }
    }
}