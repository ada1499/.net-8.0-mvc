﻿using System.Threading.Tasks;
using SapService.Models;

namespace SapService.Services
{
    internal sealed class RfcService : IRfcService
    {
        private readonly IRfcConnectionPool _connectionPool;
        private readonly RfcInfrastructure _infra = new RfcInfrastructure();

        public RfcService(IRfcConnectionPool connectionPool)
            => _connectionPool = connectionPool;

        public async Task<RfcResponse> ExecuteRfcAsync(RfcRequest request)
        {
            var dest = await _connectionPool.GetDestinationAsync(request.FuncName);
            var function = _infra.CreateFunctionWithRetry(dest, request.FuncName);
            try
            {
                _infra.SetInputParameters(function, request.Input);
                function.Invoke(dest);
                return _infra.GetOutputResults(function);
            }
            finally
            {
                _infra.ReleaseFunction(function);
            }
        }
    }
}