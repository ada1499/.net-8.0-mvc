﻿using System.Collections.Generic;

namespace SapService.Models
{
    public class SapRequest
    {
        public string FuncName { get; set; }
        public InputParams Input { get; set; }
        public OutputParams Output { get; set; }
    }

    public class InputParams
    {
        public Dictionary<string, string> Parameters { get; set; } = new Dictionary<string, string>();
        public Dictionary<string, Dictionary<string, string>> Table { get; set; } = new Dictionary<string, Dictionary<string, string>>();
    }

    public class OutputParams
    {
        public List<string> OutValue { get; set; } = new List<string>();
        public List<string> Table { get; set; } = new List<string>();
    }

    public class SapResult
    {
        public Dictionary<string, string> OutputValues { get; set; } = new Dictionary<string, string>();
        public Dictionary<string, List<Dictionary<string, string>>> OutputTables { get; set; } = new Dictionary<string, List<Dictionary<string, string>>>();
    }

    public class SapResponse
    {
        public bool Success { get; set; }
        public string Data { get; set; } = null;
        public string Error { get; set; } = null;
    }
}