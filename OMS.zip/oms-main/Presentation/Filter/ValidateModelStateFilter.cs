﻿using Domain.Exceptions;
using Microsoft.AspNetCore.Mvc.Filters;

namespace Presentation.Filter
{
    public class ValidateModelStateFilter : IActionFilter
    {
        public void OnActionExecuting(ActionExecutingContext context)
        {
            if (!context.ModelState.IsValid)
            {
                throw new ModelValidationException(context.ModelState);
            }
        }

        public void OnActionExecuted(ActionExecutedContext context) { }
    }
}
