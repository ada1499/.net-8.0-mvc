﻿using Domain.Common;
using Microsoft.AspNetCore.HttpOverrides;
using Presentation.Filter;

namespace Presentation
{
    public static class PresentationExtensions
    {
        public static IServiceCollection AddPresentations(this IServiceCollection services)
        {
            services
                .AddHttpClient()
                .AddHttpContextAccessor()
                .Configure<ForwardedHeadersOptions>(options =>
                {
                    options.ForwardedHeaders = ForwardedHeaders.XForwardedFor | ForwardedHeaders.XForwardedProto;
                    options.KnownNetworks.Clear();
                    options.KnownProxies.Clear();
                });

            services
                .AddControllersWithViews()
                    .AddJsonOptions(options =>
                    {
                        // Disable camel jump naming.
                        options.JsonSerializerOptions.PropertyNamingPolicy = null;
                        options.JsonSerializerOptions.DefaultIgnoreCondition = System.Text.Json.Serialization.JsonIgnoreCondition.WhenWritingNull;
                        options.JsonSerializerOptions.Converters.Add(new DateJsonConverter());
                    })
                    .AddRazorOptions(options =>
                    {
                        options.ViewLocationFormats.Add("/Views/OMS/{1}/{0}.cshtml");
                        options.ViewLocationFormats.Add("/Views/OMS/{0}.cshtml");
                    });

            services.AddControllersWithViews(options =>
            {
                options.Filters.Add(new ValidateModelStateFilter());
            });

            return services;
        }
    }
}
