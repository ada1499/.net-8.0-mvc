﻿namespace Presentation.Components
{
    public class SearchViewComponent(IDropdownService dropdownService) : ViewComponent
    {
        private readonly IDropdownService _dropdownService = dropdownService;

        public async Task<IViewComponentResult> InvokeAsync(Type searchModelType, string actionName)
        {
            var dropdownOptions = await _dropdownService.GetDropDownAsync(searchModelType);
            var viewModel = new SearchViewModel(searchModelType, actionName, dropdownOptions);
            return View("~/Views/Shared/Components/_SearchForm.cshtml", viewModel);
        }
    }
}
