﻿namespace Presentation.Components
{
    public class MenuViewComponent(IMenuService menuService) : ViewComponent
    {
        private readonly IMenuService _menuService = menuService;

        public async Task<IViewComponentResult> InvokeAsync()
        {
            var viewModel = await _menuService.GetSidebarMenuAsync();
            return View("~/Views/Shared/Components/_Sidebar.cshtml", viewModel);
        }
    }
}
