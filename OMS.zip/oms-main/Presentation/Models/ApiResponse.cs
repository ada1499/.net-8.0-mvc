﻿namespace Presentation.Models
{
    public record ApiResponse<T>(
        string Status = "success",
        string? Message = null,
        T? Data = default,
        ApiError? Error = null,
        ApiMeta? Meta = null);

    public record ApiError(
        string Code,
        string Message,
        object? Details = null,
        string? TraceId = null);

    public record ApiMeta(
        Pagination? Pagination);

    public record Pagination(
        int Total,
        int Page,
        int Size);
}
