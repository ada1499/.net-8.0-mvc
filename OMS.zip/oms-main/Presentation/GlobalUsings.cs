﻿global using Application.Dtos;
global using Application.Dtos.OMS;
global using Application.Interfaces;
global using Application.Interfaces.OMS;
global using Presentation.Models;
global using Microsoft.AspNetCore.Mvc;
