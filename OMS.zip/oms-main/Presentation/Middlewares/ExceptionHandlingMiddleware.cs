﻿using Domain.Exceptions;
using System.ComponentModel.DataAnnotations;

namespace Presentation.Middlewares
{
    public class ExceptionHandlingMiddleware(RequestDelegate next, ILogger<ExceptionHandlingMiddleware> logger)
    {
        private readonly RequestDelegate _next = next;
        private readonly ILogger<ExceptionHandlingMiddleware> _logger = logger;

        public async Task InvokeAsync(HttpContext context)
        {
            try
            {
                await _next(context);
            }
            catch(Exception ex)
            {
                await HandleExceptionAsync(context, ex);
            }
        }

        public async Task HandleExceptionAsync(HttpContext context, Exception ex)
        {
            var traceId = context.TraceIdentifier;
            _logger.LogError(ex, "Unhandled exception: TraceId: {TraceId}, Path: {Path}, Method: {Method}", traceId, context.Request.Path, context.Request.Method);

            var response = new ApiResponse<object>(
                Status: "error",
                Error: new ApiError(
                    Code: GetErrorCode(ex),
                    Message: GetMessage(ex),
                    Details: ex.Data.Count > 0 ? ex.Data : null,
                    TraceId: traceId
                )
            );

            context.Response.StatusCode = GetStatusCode(ex);
            await context.Response.WriteAsJsonAsync(response);
        }

        private static int GetStatusCode(Exception ex)
            => ex switch
            {
                ValidationException => StatusCodes.Status400BadRequest,
                ModelValidationException => StatusCodes.Status400BadRequest,
                UnauthorizedAccessException => StatusCodes.Status401Unauthorized,
                NotFoundException => StatusCodes.Status404NotFound,
                ArgumentNullException => StatusCodes.Status400BadRequest,
                ApiException apiEx => (int)apiEx.StatusCode,
                _ => StatusCodes.Status500InternalServerError
            };

        private static string GetErrorCode(Exception ex)
            => ex switch
            {
                ValidationException => "VALIDATION_ERROR",
                ModelValidationException => "MODEL_VALIDATION_FAILED",
                ArgumentNullException => "MISSING_PARAMETER",
                ApiException => "CALL_API_ERROR",
                _ => "INTERNAL_ERROR"
            };

        private static string GetMessage(Exception ex)
            => ex switch
            {
                ValidationException => "Input validation failed",
                ModelValidationException => "Input model validation failed",
                ApiException apiEx => apiEx.Message,
                _ => ex.Message
            };
    }
}
