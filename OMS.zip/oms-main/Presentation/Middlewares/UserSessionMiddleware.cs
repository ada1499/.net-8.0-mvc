﻿using Domain.Services.Interfaces;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;

namespace Presentation.Middlewares
{
    public class UserSessionMiddleware(RequestDelegate next)
    {
        private readonly RequestDelegate _next = next;

        public async Task InvokeAsync(HttpContext context)
        {
            if (context.User.Identity?.IsAuthenticated == true)
            {
                var sessionCache = context.RequestServices.GetRequiredService<IUserSessionCache>();
                var username = context.User.Identity.Name!;
                var clientIp = GetClientIp(context);
                var session = sessionCache.GetSession(username);

                //if (session is null || session.IpAddress != clientIp)
                //{
                //    await HandleInvalidSession(context, sessionCache, username);
                //    return;
                //}
            }

            await _next(context);
        }

        public static string GetClientIp(HttpContext context) =>
            context.Request.Headers["X-Forwarded-For"].FirstOrDefault() ??
            context.Connection.RemoteIpAddress?.ToString() ??
            "UnKnown";

        public static async Task HandleInvalidSession(HttpContext context, IUserSessionCache cache, string username)
        {
            cache.RemoveSession(username);
            await context.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            var linkGenerator = context.RequestServices.GetRequiredService<LinkGenerator>();
            var redirectUrl = linkGenerator.GetPathByAction(context, "Index", "Account");
            context.Response.Redirect(redirectUrl!);
        }
    }
}
