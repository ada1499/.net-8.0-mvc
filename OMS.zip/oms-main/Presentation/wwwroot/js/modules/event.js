﻿export class Event {
    constructor(core) {
        this.core = core;
    }

    bindEvents() {
        this.bindCheckBoxEvents();
        this.bindPaginationEvents();
        this.bindFormEvents();
        this.bindListener();
        this.bindButtonEvents();
    }

    bindCheckBoxEvents() {
        const selectAll = document.querySelector(this.core.config.selectors.selectAll);
        const tableBody = document.querySelector(this.core.config.selectors.tableBody);

        if (selectAll) {
            selectAll.addEventListener('change', e => {
                const checkboxes = document.querySelectorAll('.rowCheckBox:not(:disabled)');
                const highlightClass = 'highlight';

                checkboxes.forEach(checkbox => {
                    checkbox.checked = e.target.checked;
                    const tr = checkbox.closest('tr');
                    tr?.classList.toggle(highlightClass, e.target.checked);
                });
            });
        }

        if (tableBody) {
            tableBody.addEventListener('change', e => {
                if (e.target.classList.contains('rowCheckBox')) {
                    const tr = e.target.closest('tr');
                    tr?.classList.toggle('highlight', e.target.checked);
                }
            });
        }
    }

    bindPaginationEvents() {
        const { pagination } = this.core.config.selectors;

        const prevPage = document.querySelector(pagination.prevPage);
        if (prevPage) {
            prevPage.addEventListener('click', () => this.modules.pagination.changePage(-1));
        }

        const nextPage = document.querySelector(pagination.nextPage);
        if (nextPage) {
            nextPage.addEventListener('click', () => this.modules.pagination.changePage(1));
        }

        const pageSelect = document.querySelector(pagination.pageSelect);
        if (pageSelect) {
            pageSelect.addEventListener('change', e => {
                const page = parseInt(e.target.value);
                if (!isNaN(page)) {
                    this.modules.pagination.goToPage(page);
                }
            });
        }
    }

    bindFormEvents() {
        const searchForm = document.querySelector(this.core.config.selectors.searchForm);
        if (searchForm) {
            searchForm.addEventListener('submit', e => {
                e.preventDefault();
                this.modules.data.search(e);
            });
        }
    }

    bindListener() {
        const tableBody = document.querySelector(this.core.config.selectors.tableBody);
        if (tableBody) {
            tableBody.addEventListener('click', e => {
                const btn = e.target.closest('[data-action]');
                if (btn) {
                    e.preventDefault();
                    switch (btn.dataset.action) {
                        case 'split':
                            this.modules.data.split(btn.closest('tr'));
                            break;
                        case 'delete':
                            btn.closest('tr').remove();
                            break;
                    }
                }
            });
        }
    }

    bindButtonEvents() {
        const { buttons } = this.core.config.selectors;

        const addButtonHandler = (selector, handler) => {
            const element = document.querySelector(selector);
            if (element) {
                element.addEventListener('click', handler);
            }
        };

        addButtonHandler(buttons.upload, () => this.modules.excel.uploadExcel());
        addButtonHandler(buttons.confirm, () => this.modules.data.confirmUpload());
        addButtonHandler(buttons.cancel, () => this.modules.data.cancelPreview());
        addButtonHandler(buttons.update, (e) => {
            const url = this.core.config.apiEndpoints.update;
            const btn = e.currentTarget;
            const type = btn.dataset.dialogType;
            const title = btn.dataset.dialogTitle;
            const message = btn.dataset.dialogMessage;
            this.modules.data.update(url, type, title, message)
        });
        addButtonHandler(buttons.delete, (e) => {
            const url = this.core.config.apiEndpoints.delete;
            const btn = e.currentTarget;
            const type = btn.dataset.dialogType;
            const title = btn.dataset.dialogTitle;
            const message = btn.dataset.dialogMessage;
            this.modules.data.update(url, type, title, message)
        });
        addButtonHandler(buttons.get, () => this.modules.data.get());
        addButtonHandler(buttons.exportExcel, () => this.modules.excel.exportExcel());
    }
}
