﻿export class Dialog {
    constructor() {
        this.init();
    }

    init() {
        this.dialogElement = document.getElementById('confirmationDialog');
        if (!this.dialogElement) {
            this.createElement();
        }
        this.modal = new bootstrap.Modal(this.dialogElement, { focus: true, KeyboardEvent: true, ondrop: true });
        this.setEventListener();
    }

    createElement() {
        this.dialogElement = document.createElement('div');
        this.dialogElement.classList.add('modal', 'fade');
        this.dialogElement.id = 'confirmationDialog';
        this.dialogElement.tabIndex = -1;

        this.dialogElement.innerHTML = `
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content border-0 shadow-lg">
                    <!-- Title -->
                    <div class="modal-header bg-light">
                        <h5 id="dialogTitle"></h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <!-- Context -->
                    <div class="modal-body py-4">
                        <div class="d-flex align-items-center">
                            <i id="dialogIcon"></i>
                            <p class="mb-0" id="dialogMessage"></p>
                        </div>
                    </div>
                    <!-- Button -->
                    <div class="modal-footer bg-light">
                        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="button" class="btn btn-danger" id="confirmAction">Confirm</button>
                    </div>
                </div>
            </div>
        `;

        document.body.appendChild(this.dialogElement);
    }

    setEventListener() {
        this.confirmBtn = document.getElementById('confirmAction');
        this.confirmBtn.addEventListener('click', () => {
            this.currentCallback?.();
            this.modal.hide();
        });
    }

    show(type, title, message) {
        const dialogTitle = document.getElementById('dialogTitle');
        dialogTitle.textContent = this.getValidText(title, 'Operation confirmation');
        document.getElementById('dialogMessage').textContent = this.getValidText(message, 'Are you sure to perform this operation?');

        const icon = document.getElementById('dialogIcon');
        switch (type) {
            case 'success':
                icon.className = 'bi bi-check-circle fs-1 text-success me-3';
                dialogTitle.className = 'modal-title fw-bold text-success';
                break;
            case 'danger':
                icon.className = 'bi bi-x-circle fs-1 text-danger me-3';
                dialogTitle.className = 'modal-title fw-bold text-danger';
                break;
            case 'warning':
                icon.className = 'bi bi-exclamation-circle fs-1 text-warning me-3';
                dialogTitle.className = 'modal-title fw-bold text-warning';
                break;
            case 'info':
                icon.className = 'bi bi-info-circle fs-1 text-info me-3';
                dialogTitle.className = 'modal-title fw-bold text-info';
                break;
            default:
                icon.className = 'bi bi-question-circle fs-1 text-primary me-3';
                dialogTitle.className = 'modal-title fw-bold text-primary';
                break;
        }

        return new Promise(resolve => {
            this.currentCallback = () => {
                resolve(true);
                this.modal.hide();
            };

            this.dialogElement.addEventListener("hide.bs.modal", () => {
                resolve(false);
            });
            this.modal.show();
        });
    }

    getValidText(value, defaultValue) {
        if (value === null ||
            value === undefined ||
            value.trim() === '') {
            return defaultValue;
        }
        return value;
    }
}
