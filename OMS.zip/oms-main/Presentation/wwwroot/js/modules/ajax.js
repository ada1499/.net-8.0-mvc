﻿export class Ajax {
    async fetchAjax(url, options) {
        try {
            const response = await fetch(url, options);

            if (response.status === 404)
                throw new Error(response.status + ": Not Found");

            const result = await response.json();

            if (result.status === "error") {
                const errorMessage = JSON.stringify(result.error);
                throw new Error(errorMessage);
            }

            const contentType = response.headers.get('content-type');
            return contentType?.includes('application/json')
                ? result
                : null;
        } catch (error) {
            throw new Error("Error during fetch:" + error.message);
        }
    }
}
