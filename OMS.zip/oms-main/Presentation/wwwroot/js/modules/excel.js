﻿export class Excel {
    constructor(core) {
        this.core = core;
    }

    uploadExcel() {
        const file = document.querySelector(this.core.config.selectors.excelFile).files[0];
        if (!file) return this.modules.alert.show('Please upload the file!', 'warning');

        this.core.state.originalData = {
            data: [...this.core.state.data],
            columns: [...this.core.state.columns]
        };

        const reader = new FileReader();
        reader.readAsArrayBuffer(file);

        reader.onload = (e) => {
            try {
                const wb = XLSX.read(e.target.result, { type: 'array', cellDates: true });
                const ws = wb.Sheets[wb.SheetNames[0]];
                const data = XLSX.utils.sheet_to_json(ws, { header: 1 });
                this.renderExcel(data);
            } catch (error) {
                this.modules.alert.show('Parse excel file failed. Please check the file format.' + error.message, "danger", 0);
            } finally {
                Object.entries(this.core.config.selectors.buttons)
                    .filter(([key]) => !['confirm', 'cancel', 'get', 'exportExcel'].includes(key))
                    .forEach(([, selector]) => {
                        document.querySelector(selector)?.style.setProperty('display', 'none', 'important');
                    });
                document.querySelector(this.core.config.selectors.excelFile).classList.add('d-none');
                document.querySelector(this.core.config.selectors.confirmBtns).classList.replace('d-none', 'd-flex');
            }
        };
    }

    async renderExcel(data) {
        const [headers, ...rows] = data;
        const dateFields = new Set(this.core.specialFields.dateFields);

        const baseData = rows.map((row, i) => ({
            F_ID: i + 1,
            ...headers.reduce((obj, h, idx) => {
                let val = row[idx] ?? '';
                if (typeof val === 'string') val = val.trim();
                obj[h] = dateFields.has(h) ? XLSX.SSF.format('yyyy-MM-dd', val) : val;
                return obj;
            }, {})
        }));

        let enhancedData = [];
        if (this.core.config.backendFields?.length) {
            const payload = baseData.map(row =>
                this.core.config.backendFields.reduce((p, field) => {
                    if (row[field] !== undefined) {
                        p[field] = row[field] === '' ? null : row[field];
                    }
                    return p;
                }, {})
            );

            const response = await this.modules.data.postData(
                this.core.config.apiEndpoints.payload,
                payload
            );
            enhancedData = response.Data.Data || [];
        }

        const enhancedMap = enhancedData.reduce((map, { F_ID, ...rest }) =>
            F_ID ? map.set(F_ID, rest) : map, new Map()
        );

        this.core.state.data = baseData.map(item =>
            enhancedMap.has(item.F_ID)
                ? { ...item, ...enhancedMap.get(item.F_ID) }
                : item
        );

        this.modules.pagination.renderPagination();
        this.modules.table.renderTable(true);
    }

    exportExcel() {
        if (!this.core.state.data.length) {
            return this.modules.alert.show('No data to export!', 'warning');;
        }

        const wsData = this.prepareWorksheetData();
        const ws = XLSX.utils.aoa_to_sheet(wsData);
        this.setExcelColumnFormats(ws);
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, this.core.config.fileName);
        XLSX.writeFile(wb, this.core.config.fileName + ".xlsx");
    }

    prepareWorksheetData() {
        const dateColIndices = this.getDateColumnIndices();

        return [
            this.core.state.columns,
            ...this.core.state.data.map(item =>
                this.core.state.columns.map((col, index) => {
                    const value = item[col];
                    return dateColIndices.has(index)
                        ? this.formatDateValue(value)
                        : value ?? '';
                })
            )
        ];
    }

    getDateColumnIndices() {
        return new Set(
            this.core.specialFields.dateFields
                .map(col => this.core.state.columns.indexOf(col))
                .filter(index => index !== -1)
        );
    }

    formatDateValue(value) {
        if (!value) return '';

        const date = new Date(value);
        return isNaN(date)
            ? value
            : XLSX.SSF.format('yyyy-mm-dd', date);
    }

    setExcelColumnFormats(ws) {
        const dateColIndices = this.getDateColumnIndices();
        ws['!cols'] = this.core.state.columns.map((_, index) =>
            dateColIndices.has(index)
                ? { width: 12, numFmt: 'yyyy-mm-dd' }
                : undefined
        );
    }
}
