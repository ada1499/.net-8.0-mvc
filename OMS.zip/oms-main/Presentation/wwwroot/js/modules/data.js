﻿export class Data {
    constructor(core) {
        this.core = core;
    }

    async search(e) {
        this.modules.loading.showLoading();

        try {
            const formData = new FormData(e.target);
            const response = await this.modules.ajax.fetchAjax(this.core.config.apiEndpoints.search, { method: 'POST', body: formData });

            this.core.state.data = response.Data.Data;
            this.core.state.currentPage = 1;
            this.modules.pagination.renderPagination();
            this.modules.table.renderTable();
        } catch (error) {
            this.modules.alert.show(error.message, "danger", 0);
        } finally {
            this.modules.loading.hideLoading();
        }
    }

    async get() {
        this.modules.loading.showLoading();

        try {
            const response = await this.modules.ajax.fetchAjax(this.core.config.apiEndpoints.get, {
                method: 'GET',
                headers: { 'Content-Type': 'application/json' }
            });

            const message = JSON.stringify(response?.Message, null, 0) ?? 'Get successful!';
            this.modules.alert.show(message, "success");
        } catch {
            this.modules.alert.show(error.message, "danger", 0);
        } finally {
            await this.search({
                target: document.querySelector(this.core.config.selectors.searchForm),
                preventDefault: () => { }
            });

            this.modules.loading.hideLoading();
        }
    }

    async confirmUpload() {
        const confirmed = await this.modules.dialog.show(null, "Operation confirmation", "Are you sure you want to upload the excel data?");
        if (!confirmed) return;

        this.modules.loading.showLoading();

        try {
            const response = await this.modules.ajax.fetchAjax(this.core.config.apiEndpoints.uploadExcel, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(this.core.state.data)
            });

            const message = JSON.stringify(response?.Message, null, 0) ?? 'Upload successful!';
            this.modules.alert.show(message, "success");
        } catch (error) {
            this.modules.alert.show(error.message, "danger", 0);
        } finally {
            await this.search({
                target: document.querySelector(this.core.config.selectors.searchForm),
                preventDefault: () => { }
            });

            Object.entries(this.core.config.selectors.buttons)
                .filter(([key]) => !['confirm', 'cancel', 'get', 'exportExcel'].includes(key))
                .forEach(([, selector]) => {
                    document.querySelector(selector)?.style.removeProperty('display');
                });
            document.querySelector(this.core.config.selectors.excelFile).classList.remove('d-none');
            document.querySelector(this.core.config.selectors.confirmBtns).classList.replace('d-flex', 'd-none');

            this.modules.loading.hideLoading();
        }
    }

    async postData(url, data) {
        try {
            this.modules.loading.showLoading();

            return await this.modules.ajax.fetchAjax(url, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data)
            });
        } catch (error) {
            this.modules.alert.show(error.message, "danger", 0);
        } finally {
            this.modules.loading.hideLoading();
        }
    }

    async update(url, type, title, message) {
        const confirmed = await this.modules.dialog.show(type, title, message);
        if (!confirmed) return;

        this.modules.loading.showLoading();

        try {
            const updates = [...document.querySelectorAll('.rowCheckBox:checked')]
                .flatMap(checkbox => {
                    const row = checkbox.closest('tr');
                    if (!row?.dataset.original) return [];

                    const originalData = JSON.parse(row.dataset.original);
                    const currentData = Object.fromEntries(
                        [...row.querySelectorAll('[data-field]')].map(input => [
                            input.dataset.field,
                            input.value?.trim() || null
                        ])
                    );

                    return [{ ...originalData, ...currentData }];
                });

            if (!updates.length) return this.modules.alert.show('No rows selected', 'warning');

            const response = await this.modules.ajax.fetchAjax(url, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(updates)
            });

            const message = JSON.stringify(response?.Message, null, 0) ?? 'Commit successful!';
            this.modules.alert.show(message, "success");
        } catch (error) {
            this.modules.alert.show(error.message, "danger", 0);
        } finally {
            await this.search({
                target: document.querySelector(this.core.config.selectors.searchForm),
                preventDefault: () => { }
            });

            this.modules.loading.hideLoading();
        }
    }

    cancelPreview() {
        this.modules.loading.showLoading();
        this.core.state.columns = this.core.state.originalData.columns;
        this.core.state.data = this.core.state.originalData.data;
        this.modules.pagination.renderPagination();
        this.modules.table.renderTable();
        Object.entries(this.core.config.selectors.buttons)
            .filter(([key]) => !['confirm', 'cancel', 'get', 'exportExcel'].includes(key))
            .forEach(([, selector]) => {
                document.querySelector(selector)?.style.removeProperty('display');
            });
        document.querySelector(this.core.config.selectors.excelFile).classList.remove('d-none');
        document.querySelector(this.core.config.selectors.confirmBtns).classList.replace('d-flex', 'd-none');

        this.modules.loading.hideLoading();
    }

    split(sourceRow) {
        const original = JSON.parse(sourceRow.dataset.original);
        const cloned = structuredClone(original);
        cloned.isCloned = true;

        const qtyFields = this.core.specialFields?.qtyFields;
        if (qtyFields?.length) {
            for (const field of qtyFields) {
                cloned[field] = 0;
            }
        }

        sourceRow.insertAdjacentHTML('afterend', this.modules.table.generateRowHtml(cloned, false, true, true));
    }
}
