﻿export class Loading {
    constructor() {
        this.loadingElement = null;
    }

    createElement() {
        this.loadingElement = document.createElement('div');
        this.loadingElement.classList.add('loading-overlay', 'show');

        const spinner = document.createElement('div');
        spinner.classList.add('loading-spinner');
        this.loadingElement.appendChild(spinner);
        document.body.appendChild(this.loadingElement);
    }

    showLoading() {
        if (!this.loadingElement) {
            this.createElement();
        }

        document.querySelectorAll('button').forEach(btn => {
            btn.setAttribute('data-previous-state', btn.disabled);
            btn.disabled = true;
        });
    }

    hideLoading() {
        if (this.loadingElement) {
            document.body.removeChild(this.loadingElement);
            this.loadingElement = null;
        }

        document.querySelectorAll('button').forEach(btn => {
            const previousState = btn.dataset.previousState;
            btn.disabled = previousState === 'true';
            btn.removeAttribute('data-previous-state');
        });
    }
}
