﻿export class Alert {
    show(message, type = 'warning', duration = 5000) {
        const alertId = `alert-${Date.now()}`;
        const iconMap = {
            warning: `
                <path d="M12 9v4"></path>
                <path d="M10.363 3.591l-8.106 13.534a1.914 1.914 0 0 0 1.636 2.871h16.214a1.914 1.914 0 0 0 1.636 -2.87l-8.106 -13.536a1.914 1.914 0 0 0 -3.274 0z"></path>
                <path d="M12 16h.01"></path>`,
            danger: `
                <path d="M3 12a9 9 0 1 0 18 0a9 9 0 0 0 -18 0"></path>
                <path d="M12 8v4" ></path>
                <path d="M12 16h.01"></path>`,
            success: `
                <path d="M5 12l5 5l10 -10"></path>`,
            info: `
                <path d="M3 12a9 9 0 1 0 18 0a9 9 0 0 0 -18 0"></path>
                <path d="M12 9h.01"></path>
                <path d="M11 12h1v4h1"></path>`
        };

        // Create alert element
        const alertEl = document.createElement('div');
        alertEl.id = alertId;
        alertEl.className = `custom-alert alert-${type}`;
        alertEl.role = "alert";
        alertEl.innerHTML = `
            <div class="alert-content">
                <div class="alert-icon">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" 
                         fill="none" stroke="currentColor" stroke-width="2" 
                         stroke-linecap="round" stroke-linejoin="round">
                        ${iconMap[type]}
                    </svg>
                </div>
                <div class="alert-message">${message}</div>
                <button type="button" class="alert-close" aria-label="Close">
                    <span>&times;</span>
                </button>
            </div>
        `;

        document.body.appendChild(alertEl);

        // Add the closing event.
        alertEl.querySelector('.alert-close').addEventListener('click', () => {
            this.removeAlert(alertId);
        });

        // Auto off
        if (duration > 0) {
            setTimeout(() => this.removeAlert(alertId), duration);
        }
    }

    removeAlert(id) {
        const alert = document.getElementById(id);
        if (alert) {
            alert.classList.add('fade-out');
            setTimeout(() => {
                if (alert.parentNode) {
                    alert.parentNode.removeChild(alert);
                }
            }, 300);
        }
    }
}
