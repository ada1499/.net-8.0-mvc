﻿class SidebarAccordion {
    constructor(selector = '#sidebar') {
        this.sidebar = document.querySelector(selector);
        this.initEvents();
        this.setActiveMenuItem();
    }

    setActiveMenuItem() {
        const currentUrl = window.location.pathname;
        this.sidebar?.querySelectorAll('.submenu-link').forEach(link => {
            const linkUrl = new URL(link.href).pathname;
            if (linkUrl === currentUrl) {
                link.classList.add('active');

                const collapse = link.closest('.collapse');
                if (collapse && !collapse.classList.contains('show')) {
                    bootstrap.Collapse.getInstance(collapse)?.show();
                }
            }
        });
    }

    initEvents() {
        this.sidebar?.querySelectorAll('.submenu-link').forEach(link => {
            link.addEventListener('click', function (e) {
                document.querySelectorAll('.submenu-link').forEach(el => {
                    el.classList.remove('active');
                });
                this.classList.add('active');
            });
        });

        this.sidebar?.querySelectorAll('.collapse').forEach(collapse => {
            collapse.addEventListener('show.bs.collapse', this.handleShow);
            collapse.addEventListener('hide.bs.collapse', this.handleHide);
        });
    }

    handleShow = (e) => {
        if (!e.target.classList.contains('show')) {
            this.closeOthers(e.target);
            this.toggleIcon(e.target, true);
        }
    };

    handleHide = (e) => {
        this.toggleIcon(e.target, false);
    };

    closeOthers(currentCollapse) {
        this.sidebar?.querySelectorAll('.collapse').forEach(collapse => {
            if (collapse !== currentCollapse && collapse.classList.contains('show')) {
                bootstrap.Collapse.getInstance(collapse)?.hide();
            }
        });
    }

    toggleIcon(collapse, isOpen) {
        const icon = collapse.previousElementSibling?.querySelector('.collapse-icon');
        icon?.classList.toggle('rotate-90', isOpen);
    }
}

document.addEventListener('DOMContentLoaded', () => new SidebarAccordion());
