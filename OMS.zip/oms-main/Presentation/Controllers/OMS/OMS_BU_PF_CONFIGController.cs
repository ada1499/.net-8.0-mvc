﻿using Model = Domain.Models.Entities.OMS.BU_PF_Config;
using ModelSearch = Application.Dtos.OMS.OMS_BU_PF_CONFIG_Search;

namespace Presentation.Controllers.OMS
{
    public class OMS_BU_PF_CONFIGController(IBU_PF_ConfigService configService, IDataExecutorService dataService) : BaseController(dataService)
    {
        private readonly IBU_PF_ConfigService _configService = configService;
        private const string TView = "BU_PF_CONFIG";

        public async Task<IActionResult> Index()
        {
            var data = await _configService.GetBU_PF_ConfigAsync();
            return await PartialView(TView, data);
        }

        public async Task<IActionResult> Search([FromForm] ModelSearch request)
        {
            var data = await _configService.GetBU_PF_ConfigAsync(request);
            return await Search(data);
        }

        public async Task<IActionResult> Insert([FromBody] List<Model> request)
        {
            await _configService.AddBU_PF_ConfigAsync(request);
            return Ok(new ApiResponse<object> { Message = "Insert BU and product family config success" });
        }
    }
}
