﻿using Model = Application.Dtos.OMS.OMS_3B2RTS_PROCESS;
using ModelSearch = Application.Dtos.OMS.OMS_3B2RTS_PROCESS_Search;

namespace Presentation.Controllers.OMS
{
    public class OMS_3B2RTS_PROCESSController(IDataExecutorService spService, ICatchSCMData catchSCMData) : BaseController(spService)
    {
        private const string TView = "3B2RTS_PROCESS";
        private const string SpName = "OMS_3B2RTS_WEB";
        private const string FuncGetData = "GET_3B2RTS_PROCESS_DATA";
        private const string FuncCommit = "COMMIT_3B2RTS_PROCESS";

        private readonly ICatchSCMData _catchSCMData = catchSCMData;

        public async Task<IActionResult> Index()
            => await PartialView<Model>(TView, SpName, FuncGetData);

        [HttpPost]
        public async Task<IActionResult> Search([FromForm] ModelSearch request)
            => await Search<Model>(SpName, FuncGetData, request);

        [HttpGet]
        public async Task<IActionResult> CatchScmData()
        {
            await _catchSCMData.CatchScmPoAsync();
            return Ok(new ApiResponse<object> { Message = "Catch SCM data successful" });
        }

        [HttpPost]
        public async Task<IActionResult> Update([FromBody] List<Model> request)
            => await Update(SpName, FuncCommit, request);
    }
}
