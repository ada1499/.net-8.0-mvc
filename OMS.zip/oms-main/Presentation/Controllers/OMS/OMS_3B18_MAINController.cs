﻿using Model = Application.Dtos.OMS.OMS_3B18_MAIN;
using ModelSearch = Application.Dtos.OMS.OMS_3B18_MAIN_Search;

namespace Presentation.Controllers.OMS
{
    public class OMS_3B18_MAINController(IDataExecutorService spService, IDNService dnService) : BaseController(spService)
    {
        private readonly IDNService _dnService = dnService;
        private const string TView = "3B18_MAIN";
        private const string SpName = "OMS_3B18_WEB";
        private const string FuncGetData = "GET_3B18_MAIN_DATA";

        public async Task<IActionResult> Index()
            => await PartialView<Model>(TView, SpName, FuncGetData);

        [HttpPost]
        public async Task<IActionResult> Search([FromForm] ModelSearch request)
            => await Search<Model>(SpName, FuncGetData, request);

        [HttpPost]
        public async Task<IActionResult> CreateDN([FromBody] List<OMS_DN_Request> request)
        {
            await _dnService.CreateDNAsync(request);
            return Ok(new ApiResponse<object> { Message = "Create DN successful" });
        }
    }
}
