﻿using ModelSearch = Application.Dtos.OMS.OMS_DN_MAPPING_Search;

namespace Presentation.Controllers.OMS
{
    public class OMS_DN_MAPPINGController(IDnMappingService mappingService, IDataExecutorService dataService) : BaseController(dataService)
    {
        private readonly IDnMappingService _mappingService = mappingService;
        private const string TView = "DN_MAPPING";

        public async Task<IActionResult> Index()
        {
            var data = await _mappingService.GetDNMappingAsync();
            return await PartialView(TView, data);
        }

        public async Task<IActionResult> Search([FromForm] ModelSearch request)
        {
            var data = await _mappingService.GetDNMappingAsync(request);
            return await Search(data);
        }
    }
}
