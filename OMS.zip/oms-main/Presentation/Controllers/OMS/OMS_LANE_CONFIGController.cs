﻿using Model = Domain.Models.Entities.OMS.Lane_Config;
using ModelSearch = Application.Dtos.OMS.OMS_LANE_CONFIG_Search;

namespace Presentation.Controllers.OMS
{
    public class OMS_LANE_CONFIGController(ILaneConfigService laneConfigService, IDataExecutorService dataService) : BaseController(dataService)
    {
        private readonly ILaneConfigService _laneConfigService = laneConfigService;
        private const string TView = "LANE_CONFIG";

        public async Task<IActionResult> Index()
        {
            var data = await _laneConfigService.GetLane_ConfigsAsync();
            return await PartialView(TView, data);
        }

        public async Task<IActionResult> Search([FromForm] ModelSearch request)
        {
            var data = await _laneConfigService.GetLane_ConfigsAsync(request);
            return await Search(data);
        }

        public async Task<IActionResult> Update([FromBody] List<Model> request)
        {
            await _laneConfigService.UpdateLane_ConfigsAsync(request);
            return Ok(new ApiResponse<object> { Message = "Update lane config success" });
        }

        public async Task<IActionResult> Insert([FromBody] List<Model> request)
        {
            await _laneConfigService.AddLane_ConfigsAsync(request);
            return Ok(new ApiResponse<object> { Message = "Insert lane config success" });
        }
    }
}
