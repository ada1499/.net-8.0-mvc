﻿using Model = Application.Dtos.OMS.OMS_DELETE_DN;
using ModelSearch = Application.Dtos.OMS.OMS_DELETE_DN_Search;

namespace Presentation.Controllers.OMS
{
    public class OMS_DELETE_DNController(IDataExecutorService spService, IDNService dnService) : BaseController(spService)
    {
        private readonly IDNService _dnService = dnService;
        private const string TView = "DELETE_DN";
        private const string SpName = "OMS_CREATE_DN";
        private const string FuncGetData = "GET_DN_DETAIL";

        public async Task<IActionResult> Index()
            => await PartialView<Model>(TView, SpName, FuncGetData);

        [HttpPost]
        public async Task<IActionResult> Search([FromForm] ModelSearch request)
            => await Search<Model>(SpName, FuncGetData, request);

        [HttpPost]
        public async Task<IActionResult> DeleteDN([FromBody] List<OMS_DN_DELETE_Request> request)
        {
            await _dnService.DeleteDNAsync(request);
            return Ok(new ApiResponse<object> { Message = "Delete DN successful" });
        }
    }
}
