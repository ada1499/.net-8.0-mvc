﻿using Model = Application.Dtos.OMS.OMS_3B2RTS_MAIN;
using ModelSearch = Application.Dtos.OMS.OMS_3B2RTS_MAIN_Search;

namespace Presentation.Controllers.OMS
{
    public class OMS_3B2RTS_MAINController(IDataExecutorService spService) : BaseController(spService)
    {
        private const string TView = "3B2RTS_MAIN";
        private const string SpName = "OMS_3B2RTS_WEB";
        private const string FuncGetData = "GET_3B2RTS_MAIN_DATA";
        private const string FuncUpdate = "RESEND_3B2RTS_MAIN";
        private const string FuncGetConfig = "GET_3B2RTS_CONFIG";
        private const string FuncInsert = "INSERT_3B2RTS_MAIN";

        public async Task<IActionResult> Index()
            => await PartialView<Model>(TView, SpName, FuncGetData);

        [HttpPost]
        public async Task<IActionResult> Search([FromForm] ModelSearch request)
            => await Search<Model>(SpName, FuncGetData, request);

        [HttpPost]
        public async Task<IActionResult> Resend3B2RTS([FromBody] List<Model> request)
            => await Update(SpName, FuncUpdate, request);

        [HttpPost]
        public async Task<IActionResult> Get3B2RTSConfig([FromBody] List<OMS_3B2RTS_MAIN_CONFIG> request)
            => await Search<OMS_3B2RTS_MAIN_CONFIG>(SpName, FuncGetConfig, request);

        [HttpPost]
        public async Task<IActionResult> UploadExcel([FromBody] List<Model> request)
            => await Update(SpName, FuncInsert, request);
    }
}
