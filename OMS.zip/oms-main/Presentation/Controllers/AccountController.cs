﻿using System.Security.Claims;

namespace Presentation.Controllers
{
    public class AccountController(IAccountService accountService) : Controller
    {
        private readonly IAccountService _accountService = accountService;

        public IActionResult Index()
        {
            //var username = User.FindFirstValue(ClaimTypes.Name);
            var username = "Admin";
            var clientIp = HttpContext.Connection.RemoteIpAddress?.ToString();

            _accountService.Login(username!, clientIp!);

            return RedirectToAction("Index", "Home");
        }
    }
}
