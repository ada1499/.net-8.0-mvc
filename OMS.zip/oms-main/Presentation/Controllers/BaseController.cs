﻿namespace Presentation.Controllers
{
    public abstract class BaseController(IDataExecutorService spService) : Controller
    {
        protected readonly IDataExecutorService _spService = spService;

        public virtual async Task<IActionResult> PartialView<T>(string partialView, string spName, string funcName) where T : class
        {
            var viewModel = await _spService.GetFuncJsonParamProcedureModelDataAsync<T>(spName, funcName);
            return PartialView(partialView, viewModel);
        }

        public virtual async Task<IActionResult> PartialView<T>(string partialView, IEnumerable<T> data) where T : class
        {
            var viewModel = await _spService.GetModelDataAsync(data);
            return PartialView(partialView, viewModel);
        }

        public virtual async Task<IActionResult> Search<T>(string spName, string funcName, object request) where T : class
        {
            var viewModel = await _spService.GetFuncJsonParamProcedureModelDataAsync<T>(spName, funcName, request);
            return Ok(new ApiResponse<ViewModel<T>> { Data = viewModel });
        }

        public virtual async Task<IActionResult> Search<T>(IEnumerable<T> data) where T : class
        {
            var viewModel = await _spService.GetModelDataAsync(data);
            return Ok(new ApiResponse<ViewModel<T>> { Data = viewModel });
        }

        public virtual async Task<IActionResult> Update(string spName, string funcName, object request)
        {
            var message = await _spService.ExecuteFuncJsonParamProcedureAsync(spName, funcName, request);
            return Ok(new ApiResponse<object> { Message = message?.FirstOrDefault()?["Message"].ToString() ?? null });
        }
    }
}
