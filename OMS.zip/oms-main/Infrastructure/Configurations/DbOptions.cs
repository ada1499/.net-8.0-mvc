﻿namespace Infrastructure.Configurations
{
    public class DbOptions
    {
        public required string OMSDB { get; set; }
        public required string SCMDB { get; set; }
        public required string SCMDB_TEST { get; set; }
    }
}
