﻿global using Domain.Models;
global using Domain.Exceptions;
global using System.Data;
