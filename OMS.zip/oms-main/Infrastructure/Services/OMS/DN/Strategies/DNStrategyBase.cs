﻿using Domain.Models.Entities.Rfc;
using Domain.Services.Interfaces;
using Domain.Services.OMS;
using Domain.Services.Rfc;

namespace Infrastructure.Services.OMS.DN.Strategies
{
    internal abstract class DNDataStrategyBase<TData>(string flag, string tableName) : IDNDataStrategy where TData : class
    {
        public bool CanHandle(string inputFlag) => inputFlag == flag;
        public string TableName => tableName;

        public async Task<object> GetDataAsync(IDbService dbService, string flag, string recId) =>
            await dbService.QueryAsync<TData>("OMS_CREATE_DN", new 
            {
                FUNCTION = "GET_DN_DATA",
                IN_FLAG = flag,
                REC_ID = recId
            }, true);

        public RfcRequest BuildRequest(IRfcRequestBuilder requestBuilder, string flag, object data) =>
            BuildTypedRequest(requestBuilder, flag, (IEnumerable<TData>)data);

        protected abstract RfcRequest BuildTypedRequest(IRfcRequestBuilder requestBuilder, string flag, IEnumerable<TData> data);

        protected static List<Dictionary<string, string>> ConvertRows(IEnumerable<TData> data) =>
            data.Select(ConvertToRow).ToList();

        private static Dictionary<string, string> ConvertToRow(TData item) =>
            typeof(TData).GetProperties()
                .Where(p => p.CanRead)
                .ToDictionary(
                    p => p.Name,
                    p => p.GetValue(item)?.ToString() ?? string.Empty
                );
    }
}
