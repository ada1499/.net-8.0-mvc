﻿using Domain.Models.Entities.Rfc;
using Domain.Models.ValueObjects.OMS;
using Domain.Services.Rfc;

namespace Infrastructure.Services.OMS.DN.Strategies
{
    internal sealed class SodnStrategy()
        : DNDataStrategyBase<SODN>("SODN", "IN_TAB")
    {
        protected override RfcRequest BuildTypedRequest(
            IRfcRequestBuilder rfcRequest,
            string flag,
            IEnumerable<SODN> data) =>
            rfcRequest
                .WithFunction("ZCSD_NSBG_0020C")
                .WithClient("860")
                .WithSystemNumber("00")
                .AddInputValue("IN_FLAG", flag)
                .AddInputTable(TableName, ConvertRows(data))
                .Build();
    }

    internal sealed class DnbypoStrategy()
        : DNDataStrategyBase<DNBYPO>("DNBYPO", "IN_TAB2")
    {
        protected override RfcRequest BuildTypedRequest(
            IRfcRequestBuilder rfcRequest,
            string flag,
            IEnumerable<DNBYPO> data) =>
            rfcRequest
                .WithFunction("ZCSD_NSBG_0020C")
                .WithClient("860")
                .WithSystemNumber("00")
                .AddInputValue("IN_FLAG", flag)
                .AddInputTable(TableName, ConvertRows(data))
                .Build();
    }
}
