﻿using Dapper;
using Domain.Common;

namespace Infrastructure.Data
{
    public class DataTypeHandle
    {
        public static void SqlMapperConfigure()
        {
            SqlMapper.AddTypeHandler(new DateTypeHandler());
        }

        public class DateTypeHandler : SqlMapper.TypeHandler<Date?>
        {
            public override Date? Parse(object value)
                => value is DBNull ? null : new Date((DateTime)value);

            public override void SetValue(IDbDataParameter parameter, Date? value)
            {
                parameter.DbType = DbType.Date;
                parameter.Value = value?.Value ?? (object)DBNull.Value;
            }
        }
    }
}
