﻿using Dapper;
using Microsoft.Data.SqlClient;

namespace Infrastructure.Data.Dapper
{
    public interface IDbContext
    {
        ValueTask<T> UseConnectionAsync<T>(Func<SqlConnection, Task<T>> execute, CancellationToken ct = default);
        CommandDefinition CreateCommand(string command, object? parameters, bool isStoredProcedure, CancellationToken ct = default);
    }
}
