﻿using Dapper;
using Infrastructure.Configurations;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Options;

namespace Infrastructure.Data.Dapper
{
    internal sealed class DbContext(IOptions<DbOptions> options) : IDbContext, IAsyncDisposable
    {
        private readonly string _connString = options.Value.OMSDB;

        public async ValueTask<T> UseConnectionAsync<T>(Func<SqlConnection, Task<T>> execute, CancellationToken ct = default)
        {
            await using var conn = new SqlConnection(_connString);
            await conn.OpenAsync(ct);
            return await execute(conn);
        }

        public CommandDefinition CreateCommand(string command, object? parameters, bool isStoredProcedure, CancellationToken ct = default)
        {
            ArgumentException.ThrowIfNullOrEmpty(command, "Command text cannot be empty");

            return new(
                command,
                DbParametersBuilder.GetDynamicParameters(parameters),
                commandType: isStoredProcedure ? CommandType.StoredProcedure : CommandType.Text,
                cancellationToken: ct);
        }

        public ValueTask DisposeAsync()
        {
            GC.SuppressFinalize(this);
            return ValueTask.CompletedTask;
        }
    }
}
