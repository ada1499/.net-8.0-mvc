﻿using Dapper;
using Domain.Services.Interfaces;

namespace Infrastructure.Data.Dapper
{
    internal sealed class DbService(IDbContext dbContext) : IDbService
    {
        private readonly IDbContext _dbContext = dbContext;

        public async Task<IEnumerable<T>> QueryAsync<T>(string command, object? parameters = null, bool isStoredProcedure = false)
            => await _dbContext.UseConnectionAsync(conn =>
                conn.QueryAsync<T>(_dbContext.CreateCommand(command, parameters, isStoredProcedure)));

        public async Task<int> ExecuteAsync(string command, object? parameters = null, bool isStoredProcedure = false)
            => await _dbContext.UseConnectionAsync(conn =>
                conn.ExecuteAsync(_dbContext.CreateCommand(command, parameters, isStoredProcedure)));
    }
}
