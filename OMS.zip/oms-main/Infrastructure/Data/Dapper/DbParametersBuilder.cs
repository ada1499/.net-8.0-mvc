﻿using Dapper;
using Microsoft.Data.SqlClient;

namespace Infrastructure.Data.Dapper
{
    internal sealed class DbParametersBuilder
    {
        public static DynamicParameters GetDynamicParameters(object? parameters = null)
            => parameters switch
            {
                null => new(),
                DynamicParameters dp => dp,
                SqlParameter[] sqlParams => ConvertSqlParameters(sqlParams),
                IEnumerable<SqlParameter> sqlParams => ConvertSqlParameters(sqlParams),
                Dictionary<string, object> param => ConvertDictionaryParameters(param),
                _ => new DynamicParameters(parameters)
            };

        private static DynamicParameters ConvertSqlParameters(IEnumerable<SqlParameter> sqlParameters)
        {
            var dynamicParams = new DynamicParameters();
            foreach (var p in sqlParameters ?? [])
                dynamicParams.Add(p.ParameterName, p.Value);
            return dynamicParams;
        }

        private static DynamicParameters ConvertDictionaryParameters(Dictionary<string, object> parameters)
        {
            var dynamicParams = new DynamicParameters();
            foreach (var p in parameters ?? [])
                dynamicParams.Add(p.Key, p.Value);
            return dynamicParams;
        }
    }
}
