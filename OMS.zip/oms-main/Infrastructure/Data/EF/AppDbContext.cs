﻿using Domain.Models.Aggregates.Menu;
using Infrastructure.Data.EF.EntityConfigurations;
using Infrastructure.Data.EF.EntityConfigurations.OMS;
using Microsoft.EntityFrameworkCore;

namespace Infrastructure.Data.EF
{
    internal sealed class AppDbContext(DbContextOptions<AppDbContext> options) : DbContext(options), IAsyncDisposable
    {
        public DbSet<MenuAggregate> Menus { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder
                .ApplyConfiguration(new DNInfoConfiguration())
                .ApplyConfiguration(new MenuAggregateConfiguration())
                .ApplyConfiguration(new MenuGroupConfiguration())
                .ApplyConfiguration(new RTS_PROCESSConfiguration())
                .ApplyConfiguration(new RTS_MAINConfiguration())
                .ApplyConfiguration(new LaneConfigConfiguration())
                .ApplyConfiguration(new BU_PF_ConfigConfiguration())
                .ApplyConfiguration(new DNMappingConfiguration());
        }

        public override async ValueTask DisposeAsync()
        {
            await base.DisposeAsync();
            GC.SuppressFinalize(this);
        }
    }
}
