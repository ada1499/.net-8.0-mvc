﻿using Domain.Models.Entities.SCM;
using Domain.Services.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace Infrastructure.Data.EF.Repositories
{
    internal sealed class SCMRepository(SCMDbContext context) : ISCMRepository
    {
        private readonly SCMDbContext _context = context;

        public async Task<IEnumerable<BlankPoCommit>> GetBlankPoAsync()
            => await _context.BlankPoCommits
                .Include(b => b.BlankPoLine)
                .Where(b => b.F_LINESTATUS == "8" && b.F_SENDFLAG == "N")
                .AsNoTracking()
                .ToListAsync();

        public async Task<IEnumerable<StandardPoCommit>> GetStandardPoAsync()
            => await _context.StandardPoCommits
                .Include(b => b.StandardPoLine)
                .Where(b => b.F_LINESTATUS == "8" && b.F_SENDFLAG == "N")
                .AsNoTracking()
                .ToListAsync();

        public async Task BulkUpdateBlankPoAsync(IEnumerable<BlankPoCommit> entities)
        {
            var dataList = entities.ToList();
            if (!dataList.Any()) return;

            var etds = dataList.Select(e => e.F_ETD).Distinct().ToList();
            var items = dataList.Select(e => e.F_ITEM).Distinct().ToList();
            var pos = dataList.Select(e => e.F_PO).Distinct().ToList();

            await _context.BlankPoCommits
                .Where(po => etds.Contains(po.F_ETD) &&
                             items.Contains(po.F_ITEM) &&
                             pos.Contains(po.F_PO))
                .Where(po => po.F_SENDFLAG == "N")
                .ExecuteUpdateAsync(s => s.SetProperty(po => po.F_SENDFLAG, "S"));
        }

        public async Task BulkUpdateStandardPoAsync(IEnumerable<StandardPoCommit> entities)
        {
            var dataList = entities.ToList();
            if (!dataList.Any()) return;

            var etds = dataList.Select(e => e.F_ETD).Distinct().ToList();
            var items = dataList.Select(e => e.F_ITEM).Distinct().ToList();
            var pos = dataList.Select(e => e.F_PO).Distinct().ToList();

            await _context.StandardPoCommits
                .Where(po => etds.Contains(po.F_ETD) &&
                             items.Contains(po.F_ITEM) &&
                             pos.Contains(po.F_PO))
                .Where(po => po.F_SENDFLAG == "N")
                .ExecuteUpdateAsync(s => s.SetProperty(po => po.F_SENDFLAG, "S"));
        }
    }
}
