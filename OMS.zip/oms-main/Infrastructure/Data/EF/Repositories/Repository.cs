﻿using Domain.Services.Interfaces;
using EFCore.BulkExtensions;
using Microsoft.EntityFrameworkCore;
using System.Linq.Expressions;

namespace Infrastructure.Data.EF.Repositories
{
    internal sealed class Repository<T> : IRepository<T> where T : class
    {
        private readonly AppDbContext _context;
        private readonly DbSet<T> _dbset;
        private static readonly SemaphoreSlim _semaphore = new SemaphoreSlim(1, 1);

        public Repository(AppDbContext context)
        {
            _context = context;
            _dbset = _context.Set<T>();
        }

        public async Task<IEnumerable<T>> GetAllAsync()
            => await _dbset.AsNoTracking().ToListAsync();

        public async Task<IEnumerable<T>> GetDistinctAllAsync()
            => await _dbset.Distinct().AsNoTracking().ToListAsync();

        public async Task<T> GetByIdAsync(int id)
            => await _dbset.FindAsync(id);

        public async Task<IEnumerable<TResult>> GetDistinctValuesAsync<TResult>(Expression<Func<T, TResult>> selector, Expression<Func<T, bool>>? predicate = null)
        {
            IQueryable<T> qurey = _dbset.AsNoTracking();
            if (predicate != null)
                qurey = qurey.Where(predicate);

            return await qurey.Select(selector).Distinct().ToListAsync();
        }
            
        public async Task<IEnumerable<T>> GetAsync(Expression<Func<T, bool>> expression)
            => await _dbset.Where(expression).AsNoTracking().ToListAsync();

        public async Task<IEnumerable<T>> GetDistinctAsync(Expression<Func<T, bool>> expression)
            => await _dbset.Where(expression).Distinct().AsNoTracking().ToListAsync();

        public async Task AddAsync(T eneity)
            => await _dbset.AddAsync(eneity);

        public async Task AddAsync(IEnumerable<T> entities)
            => await _context.BulkInsertAsync(entities);

        public async Task UpdateAsync(T entity)
        {
            if (_context.Entry(entity).State == EntityState.Detached)
                _dbset.Attach(entity);

            await Task.Run(() => _context.Entry(entity).State = EntityState.Modified);
        }

        public async Task UpdateAsync(IEnumerable<T> entities)
            => await _context.BulkUpdateAsync(entities);

        public async Task DeleteByIdAsync(int id)
        {
            var entity = await _dbset.FindAsync(id);
            if (entity != null)
                _dbset.Remove(entity);
        }

        public async Task BulkDeleteAsync(IEnumerable<T> entities)
            => await _context.BulkDeleteAsync(entities);

        public async Task<bool> SaveChangeAsync()
        {
            try
            {
                await _semaphore.WaitAsync();
                return await _context.SaveChangesAsync() > 0;
            }
            finally
            {
                _semaphore.Release();
            }
        }

        public async Task<bool> BulkSaveChangeAsync()
        {
            try
            {
                await _semaphore.WaitAsync();
                await _context.BulkSaveChangesAsync(new BulkConfig
                {
                    BatchSize = 2000,
                    EnableStreaming = true,
                    UseTempDB = true,
                    SqlBulkCopyOptions = SqlBulkCopyOptions.TableLock
                });
                return true;
            }
            finally
            {
                _semaphore.Release();
            }
        }
    }
}
