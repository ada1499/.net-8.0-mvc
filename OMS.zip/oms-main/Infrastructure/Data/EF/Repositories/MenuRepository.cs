﻿using Domain.Models.Aggregates.Menu;
using Domain.Services.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace Infrastructure.Data.EF.Repositories
{
    internal sealed class MenuRepository(AppDbContext context) : IMenuRepository
    {
        private readonly AppDbContext _context = context;

        public async Task<MenuAggregate?> GetByIdAsync(int id)
            => await _context.Menus.FindAsync(id);

        public async Task<MenuAggregate?> GetWithGroupAsync(int id)
            => await _context.Menus
                .Include(m => m.MenuGroups)
                .ThenInclude(m => m.MenuItems)
                .FirstOrDefaultAsync(m => m.Id == id);

        public async Task AddAsync(MenuAggregate menu)
        {
            await _context.Menus.AddAsync(menu);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateAsync(MenuAggregate menu)
        {
            _context.Menus.Update(menu);
            await _context.SaveChangesAsync();
        }
    }
}
