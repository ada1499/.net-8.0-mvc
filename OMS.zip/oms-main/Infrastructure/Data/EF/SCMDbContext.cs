﻿using Domain.Models.Entities.SCM;
using Infrastructure.Data.EF.EntityConfigurations.SCM;
using Microsoft.EntityFrameworkCore;

namespace Infrastructure.Data.EF
{
    internal sealed class SCMDbContext(DbContextOptions<SCMDbContext> options) : DbContext(options), IAsyncDisposable
    {
        public DbSet<BlankPoCommit> BlankPoCommits { get; set; }
        public DbSet<StandardPoCommit> StandardPoCommits { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder
                .ApplyConfiguration(new BlankPoCommitConfiguration())
                .ApplyConfiguration(new BlankPoLineConfiguration())
                .ApplyConfiguration(new StandardPoConfiguration())
                .ApplyConfiguration(new StandardPoLineConfiguration());
        }

        public override async ValueTask DisposeAsync()
        {
            await base.DisposeAsync();
            GC.SuppressFinalize(this);
        }
    }
}
