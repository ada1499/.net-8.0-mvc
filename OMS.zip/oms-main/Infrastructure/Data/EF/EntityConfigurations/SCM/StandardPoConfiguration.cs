﻿using Domain.Models.Entities.SCM;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Infrastructure.Data.EF.EntityConfigurations.SCM
{
    internal sealed class StandardPoConfiguration : IEntityTypeConfiguration<StandardPoCommit>
    {
        public void Configure(EntityTypeBuilder<StandardPoCommit> builder)
        {
            builder.ToTable("TB_STANDARDPOCOMMIT").HasKey(b => new { b.F_ETD, b.F_ITEM, b.F_PO });
            builder.Property(b => b.ID).HasColumnName("F_ID");
            builder.Property(b => b.F_TRACKNO).HasColumnName("F_TRACKNO");
            builder.Property(b => b.F_PO).HasColumnName("F_PO");
            builder.Property(b => b.F_ITEM).HasColumnName("F_ITEM");
            builder.Property(b => b.F_NEWLINE).HasColumnName("F_NEWLINE");
            builder.Property(b => b.F_PN).HasColumnName("F_PN");
            builder.Property(b => b.F_COMMITDELIVERYDATE).HasColumnName("F_COMMITDELIVERYDATE");
            builder.Property(b => b.F_ETD).HasColumnName("F_ETD");
            builder.Property(b => b.F_PLANT).HasColumnName("F_PLANT");
            builder.Property(b => b.F_COMMITDELIVERYQTY).HasColumnName("F_COMMITDELIVERYQTY");
            builder.Property(b => b.F_POTYPE).HasColumnName("F_USERID");
            builder.Property(b => b.F_VENDORCODE).HasColumnName("F_VENDORCODE");
            builder.Property(b => b.F_LINESTATUS).HasColumnName("F_LINESTATUS");
            builder.Property(b => b.F_SENDFLAG).HasColumnName("F_SENDFLAG");

            builder.HasOne(b => b.StandardPoLine)
                .WithMany()
                .HasForeignKey(b => b.ID)
                .IsRequired();
        }
    }

    internal sealed class StandardPoLineConfiguration : IEntityTypeConfiguration<StandardPoLine>
    {
        public void Configure(EntityTypeBuilder<StandardPoLine> builder)
        {
            builder.ToTable("TB_STANDARDPOLINE").HasKey(b => b.ID);
            builder.Property(b => b.ID).HasColumnName("F_ID");
            builder.Property(b => b.ITEM_DESCRIPTION).HasColumnName("F_DESC");
        }
    }
}
