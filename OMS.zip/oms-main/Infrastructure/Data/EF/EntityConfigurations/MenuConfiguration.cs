﻿using Domain.Models.Aggregates.Menu;
using Domain.Models.Entities.Menu;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Infrastructure.Data.EF.EntityConfigurations
{
    internal sealed class MenuAggregateConfiguration : IEntityTypeConfiguration<MenuAggregate>
    {
        public void Configure(EntityTypeBuilder<MenuAggregate> builder)
        {
            builder.ToTable("OMS_MENU").HasKey(m => m.Id);
            builder.Property(m => m.Id).HasColumnName("ID").ValueGeneratedOnAdd();
            builder.Property(m => m.Name).HasColumnName("MENU_NAME").HasMaxLength(100).IsRequired();

            builder.HasMany(m => m.MenuGroups)
                .WithOne()
                .HasForeignKey("MENU_ID")
                .OnDelete(DeleteBehavior.Cascade);
        }
    }

    internal sealed class MenuGroupConfiguration : IEntityTypeConfiguration<MenuGroup>
    {
        public void Configure(EntityTypeBuilder<MenuGroup> builder)
        {
            builder.ToTable("OMS_MENU_GROUP").HasKey(m => m.Id);
            builder.Property(m => m.Id).HasColumnName("ID").ValueGeneratedOnAdd();
            builder.Property(m => m.GroupName).HasColumnName("GROUP_NAME").HasMaxLength(50).IsRequired();
            builder.Property(m => m.Action).HasColumnName("ACTION").HasMaxLength(50).IsRequired();
            builder.Property(m => m.DisplayOrder).HasColumnName("DISPLAY_ORDER").HasDefaultValue(1);

            builder.OwnsMany(m => m.MenuItems, itemBuilder =>
            {
                itemBuilder.ToTable("OMS_MENU_ITEM");
                itemBuilder.WithOwner().HasForeignKey("MENU_GROUP_ID");
                itemBuilder.Property(i => i.Text).HasColumnName("TEXT").HasMaxLength(100).IsRequired();
                itemBuilder.Property(i => i.Action).HasColumnName("ACTION").HasMaxLength(100).IsRequired();
                itemBuilder.Property(i => i.Controller).HasColumnName("CONTROLLER").HasMaxLength(100).IsRequired();
                itemBuilder.Property(i => i.DisplayOrder).HasColumnName("DISPLAY_ORDER").HasDefaultValue(1);
            });
        }
    }
}
