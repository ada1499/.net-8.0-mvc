﻿using Domain.Models.Entities.OMS;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;

namespace Infrastructure.Data.EF.EntityConfigurations.OMS
{
    internal sealed class BU_PF_ConfigConfiguration : IEntityTypeConfiguration<BU_PF_Config>
    {
        public void Configure(EntityTypeBuilder<BU_PF_Config> builder)
        {
            builder.ToTable("OTM_BU_PF_CONFIG");
            builder.HasKey(x => x.PARTNO);
            builder.Property(x => x.PARTNO).HasColumnName("PARTNO");
            builder.Property(x => x.BU).HasColumnName("BU");
            builder.Property(x => x.PRODUCT_FAMILY).HasColumnName("PRODUCT_FAMILY");
            builder.Property(x => x.LASTEDITBY).HasColumnName("LASTEDITBY");
            builder.Property(x => x.LASTEDITDT).HasColumnName("LASTEDITDT").HasDefaultValue(DateTime.UtcNow).ValueGeneratedOnAddOrUpdate();
        }
    }
}
