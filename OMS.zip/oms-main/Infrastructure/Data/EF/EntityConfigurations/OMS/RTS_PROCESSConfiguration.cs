﻿using Domain.Models.Entities.OMS;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Infrastructure.Data.EF.EntityConfigurations.OMS
{
    internal sealed class RTS_PROCESSConfiguration : IEntityTypeConfiguration<RTS_PROCESS>
    {
        public void Configure(EntityTypeBuilder<RTS_PROCESS> builder)
        {
            builder.ToTable("OTM_3B2RTS_PROCESS");
            builder.HasKey(x => x.ID);
            builder.Property(x => x.ID).HasColumnName("F_ID").HasColumnType("int").UseIdentityColumn().HasConversion<long>();
            builder.Property(x => x.F_TRACKNO).HasColumnName("F_TRACKNO");
            builder.Property(x => x.F_PO).HasColumnName("F_PO");
            builder.Property(x => x.F_ITEM).HasColumnName("F_ITEM");
            builder.Property(x => x.F_NEWLINE).HasColumnName("F_NEWLINE");
            builder.Property(x => x.F_PN).HasColumnName("F_PN");
            builder.Property(x => x.F_COMMITDELIVERYDATE).HasColumnName("F_COMMITDELIVERYDATE");
            builder.Property(x => x.F_ETD).HasColumnName("F_ETD");
            builder.Property(x => x.F_PLANT).HasColumnName("F_PLANT");
            builder.Property(x => x.F_COMMITDELIVERYQTY).HasColumnName("F_COMMITDELIVERYQTY").HasColumnType("int");
            builder.Property(x => x.F_SHIPVIA).HasColumnName("F_SHIPVIA").HasDefaultValue("AIR");
            builder.Property(x => x.F_EXPEDITEFLAG).HasColumnName("F_EXPEDITEFLAG").HasDefaultValue("N");
            builder.Property(x => x.F_POTYPE).HasColumnName("F_POTYPE");
            builder.Property(x => x.F_BU).HasColumnName("F_BU");
            builder.Property(x => x.F_PRODUCTNAME).HasColumnName("F_PRODUCTNAME");
            builder.Property(x => x.F_VENDORCODE).HasColumnName("F_VENDORCODE");
            builder.Property(x => x.F_SENDFLAG).HasColumnName("F_SENDFLAG").HasDefaultValue("N");
            builder.Property(x => x.ITEM_DESCRIPTION).HasColumnName("ITEM_DESCRIPTION");
        }
    }
}
