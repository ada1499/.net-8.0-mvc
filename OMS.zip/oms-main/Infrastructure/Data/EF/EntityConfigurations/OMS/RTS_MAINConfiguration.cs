﻿using Domain.Models.Entities.OMS;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Infrastructure.Data.EF.EntityConfigurations.OMS
{
    internal sealed class RTS_MAINConfiguration : IEntityTypeConfiguration<RTS_MAIN>
    {
        public void Configure(EntityTypeBuilder<RTS_MAIN> builder)
        {
            builder.ToTable("OTM_3B2RTS_MAIN");
            builder.HasKey(x => x.MESSAGE_ID);
            builder.Property(x => x.MESSAGE_ID).HasColumnName("MESSAGE_ID");
            builder.Property(x => x.FILE_NAME).HasColumnName("FILE_NAME");
            builder.Property(x => x.DOCTYPE).HasColumnName("DOCTYPE");
            builder.Property(x => x.PO_NUMBER).HasColumnName("PO_NUMBER");
            builder.Property(x => x.PO_LINE_NUMBER).HasColumnName("PO_LINE_NUMBER");
            builder.Property(x => x.INVENTORY_ITEM_NUMBER).HasColumnName("INVENTORY_ITEM_NUMBER");
            builder.Property(x => x.SHIPPED_QUANTITY).HasColumnName("SHIPPED_QUANTITY");
            builder.Property(x => x.PLANT).HasColumnName("PLANT");
            builder.Property(x => x.SHIP_FROM_LOCATION).HasColumnName("SHIP_FROM_LOCATION");
            builder.Property(x => x.SHIP_DATE).HasColumnName("SHIP_DATE");
            builder.Property(x => x.SHIPDATE_CODE).HasColumnName("SHIPDATE_CODE");
            builder.Property(x => x.SHIP_VIA).HasColumnName("SHIP_VIA");
            builder.Property(x => x.SHIP_TO_NAME).HasColumnName("SHIP_TO_NAME");
            builder.Property(x => x.TRANSMISSION_DATE).HasColumnName("TRANSMISSION_DATE");
            builder.Property(x => x.RECEIVER_NAME).HasColumnName("RECEIVER_NAME");
            builder.Property(x => x.RECEIVER_DUNS_NUMBER).HasColumnName("RECEIVER_DUNS_NUMBER");
            builder.Property(x => x.SENDER_NAME).HasColumnName("SENDER_NAME");
            builder.Property(x => x.SENDER_DUNS_NUMBER).HasColumnName("SENDER_DUNS_NUMBER");
            builder.Property(x => x.SENDFLAG).HasColumnName("SENDFLAG").HasDefaultValue("N");
            builder.Property(x => x.CREATEDT).HasColumnName("CREATEDT");
            builder.Property(x => x.LASTEDITDT).HasColumnName("LASTEDITDT");
            builder.Property(x => x.TRACKNO).HasColumnName("TRACKNO");
            builder.Property(x => x.ITEM_NUMBER).HasColumnName("ITEM_NUMBER");
            builder.Property(x => x.SITE_NAME).HasColumnName("SITE_NAME");
            builder.Property(x => x.PROMISE_DELIVERY_DATE).HasColumnName("PROMISE_DELIVERY_DATE");
            builder.Property(x => x.LOAD_CDB).HasColumnName("LOAD_CDB");
            builder.Property(x => x.COMMIT_DELIVERY_DATE).HasColumnName("COMMIT_DELIVERY_DATE");
            builder.Property(x => x.PACK_TYPE).HasColumnName("PACK_TYPE");
            builder.Property(x => x.EXPEDITE_FLAG).HasColumnName("EXPEDITE_FLAG");
            builder.Property(x => x.PRODUCTNAME).HasColumnName("PRODUCTNAME");
            builder.Property(x => x.BU).HasColumnName("BU");
            builder.Property(x => x.APPROVEID).HasColumnName("APPROVEID");
            builder.Property(x => x.REFERENCE_MESSAGE_ID).HasColumnName("REFERENCE_MESSAGE_ID");
            builder.Property(x => x.SHIPMENT_ID).HasColumnName("SHIPMENT_ID");
            builder.Property(x => x.ITEM_DESCRIPTION).HasColumnName("ITEM_DESCRIPTION");
        }
    }
}
