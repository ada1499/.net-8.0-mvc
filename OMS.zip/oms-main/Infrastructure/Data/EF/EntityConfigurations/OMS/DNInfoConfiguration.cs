﻿using Domain.Models.Entities.OMS;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Infrastructure.Data.EF.EntityConfigurations.OMS
{
    internal sealed class DNInfoConfiguration : IEntityTypeConfiguration<DNInfo>
    {
        public void Configure(EntityTypeBuilder<DNInfo> builder)
        {
            builder.ToTable("OTM_DN_INFO");
            builder.HasKey(x => x.REC_ID);
            builder.Property(x => x.REC_ID).HasColumnName("REC_ID");
            builder.Property(x => x.IN_FLAG).HasColumnName("IN_FLAG");
            builder.Property(x => x.O_DELIVERY_ID).HasColumnName("O_DELIVERY_ID");
            builder.Property(x => x.O_DN).HasColumnName("O_DN");
            builder.Property(x => x.O_FLAG).HasColumnName("O_FLAG");
            builder.Property(x => x.O_MESSAGE).HasColumnName("O_MESSAGE");
            builder.Property(x => x.O_SERVLEVL).HasColumnName("O_SERVLEVL");
            builder.Property(x => x.O_SO).HasColumnName("O_SO");
            builder.Property(x => x.STATUS).HasColumnName("STATUS").HasDefaultValue(0);
        }
    }
}
