﻿using Domain.Models.Entities.OMS;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;

namespace Infrastructure.Data.EF.EntityConfigurations.OMS
{
    internal sealed class LaneConfigConfiguration : IEntityTypeConfiguration<Lane_Config>
    {
        public void Configure(EntityTypeBuilder<Lane_Config> builder)
        {
            builder.ToTable("OTM_LANE_CONFIG");
            builder.HasKey(x => new { x.SHIP_FROM, x.SHIP_TO, x.SHIP_METHOD });
            builder.Property(x => x.SHIP_FROM).HasColumnName("SHIP_FROM");
            builder.Property(x => x.SHIP_TO).HasColumnName("SHIP_TO");
            builder.Property(x => x.SHIP_METHOD).HasColumnName("SHIP_METHOD");
            builder.Property(x => x.SHIP_TO_COMMENTS).HasColumnName("SHIP_TO_COMMENTS");
            builder.Property(x => x.AIRPORT_TO_AIRPORT).HasColumnName("AIRPORT_TO_AIRPORT");
            builder.Property(x => x.CARRIER).HasColumnName("CARRIER");
            builder.Property(x => x.D2D_ONWAY_DAYS).HasColumnName("D2D_ONWAY_DAYS");
            builder.Property(x => x.COMMENTS).HasColumnName("COMMENTS");
            builder.Property(x => x.LAST_EDITDT).HasColumnName("LAST_EDITDT").HasDefaultValue(DateTime.UtcNow).ValueGeneratedOnAddOrUpdate();
            builder.Property(x => x.SENDER_DUNS_NUMBER).HasColumnName("SENDER_DUNS_NUMBER");
            builder.Property(x => x.USER_ID).HasColumnName("USER_ID");
        }
    }
}
