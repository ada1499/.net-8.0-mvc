﻿using Domain.Models.Entities.OMS;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;

namespace Infrastructure.Data.EF.EntityConfigurations.OMS
{
    internal sealed class DNMappingConfiguration: IEntityTypeConfiguration<DNMapping>
    {
        public void Configure(EntityTypeBuilder<DNMapping> builder)
        {
            builder.ToTable("OTM_DN_MAPPING");
            builder.HasKey(x => new { x.SHIP_FROM, x.SHIP_TO, x.SHIP_VIA, x.LOCATION });
            builder.Property(x => x.SHIP_FROM).HasColumnName("SHIP_FROM");
            builder.Property(x => x.SHIP_TO).HasColumnName("SHIP_TO");
            builder.Property(x => x.SHIP_VIA).HasColumnName("SHIP_VIA").HasDefaultValue("Default");
            builder.Property(x => x.LOCATION).HasColumnName("LOCATION").HasDefaultValue("Default");
            builder.Property(x => x.IN_FLAG).HasColumnName("IN_FLAG");
            builder.Property(x => x.AUART).HasColumnName("AUART");
            builder.Property(x => x.VKORG).HasColumnName("VKORG");
            builder.Property(x => x.VTWEG).HasColumnName("VTWEG");
            builder.Property(x => x.SPART).HasColumnName("SPART");
            builder.Property(x => x.VKGRP).HasColumnName("VKGRP");
            builder.Property(x => x.VKBUR).HasColumnName("VKBUR");
            builder.Property(x => x.KUNAG).HasColumnName("KUNAG");
            builder.Property(x => x.KUNNR).HasColumnName("KUNNR");
            builder.Property(x => x.BSTKD).HasColumnName("BSTKD");
            builder.Property(x => x.BSTDK).HasColumnName("BSTDK");
            builder.Property(x => x.VDATU).HasColumnName("VDATU");
            builder.Property(x => x.INCO1).HasColumnName("INCO1");
            builder.Property(x => x.INCO2).HasColumnName("INCO2");
            builder.Property(x => x.VSART).HasColumnName("VSART");
            builder.Property(x => x.SDABW).HasColumnName("SDABW");
            builder.Property(x => x.WERKS).HasColumnName("WERKS");
            builder.Property(x => x.MATNR).HasColumnName("MATNR");
            builder.Property(x => x.KWMENG).HasColumnName("KWMENG");
            builder.Property(x => x.LGORT).HasColumnName("LGORT");
            builder.Property(x => x.VSTEL).HasColumnName("VSTEL");
            builder.Property(x => x.ROUTE).HasColumnName("ROUTE");
            builder.Property(x => x.LIFEX).HasColumnName("LIFEX");
            builder.Property(x => x.BSTKD_E).HasColumnName("BSTKD_E");
            builder.Property(x => x.SERVLEVL).HasColumnName("SERVLEVL");
            builder.Property(x => x.VBELN).HasColumnName("VBELN");
            builder.Property(x => x.EBELN).HasColumnName("EBELN");
            builder.Property(x => x.EBELP).HasColumnName("EBELP");
            builder.Property(x => x.MENGE).HasColumnName("MENGE");
            builder.Property(x => x.EINDT).HasColumnName("EINDT");
            builder.Property(x => x.USERID).HasColumnName("USERID").HasDefaultValue("SYSTEM");
        }
    }
}
