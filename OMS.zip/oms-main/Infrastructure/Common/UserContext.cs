﻿using Domain.Services.Interfaces;

namespace Infrastructure.Common
{
    internal sealed class UserContext(IHttpContextAccessor accessor) : IUserContext
    {
        private IHttpContextAccessor _accessor = accessor;

        public string Username =>
            //_accessor.HttpContext?.User.Identity?.Name
            "Admin"
            ?? throw new UnauthorizedAccessException("User not authenticated");
    }
}
