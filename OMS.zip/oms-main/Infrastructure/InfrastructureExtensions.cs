﻿using Domain.Services.Interfaces;
using Domain.Services.OMS;
using Domain.Services.Rfc;
using Infrastructure.Api;
using Infrastructure.Cache;
using Infrastructure.Common;
using Infrastructure.Configurations;
using Infrastructure.Data;
using Infrastructure.Data.Dapper;
using Infrastructure.Data.EF;
using Infrastructure.Data.EF.Repositories;
using Infrastructure.Sap;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using System.Reflection;

namespace Infrastructure
{
    public static class InfrastructureExtensions
    {
        public static IServiceCollection AddInfrastructure(this IServiceCollection services, IConfiguration configuration)
        {
            DataTypeHandle.SqlMapperConfigure();

            services
                .AddMemoryCache(options =>
                {
                    options.SizeLimit = 1024;
                })
                .Configure<DbOptions>(configuration.GetSection("ConnectionStrings"))
                .Configure<ApiConfig>(configuration.GetSection("ApiConfig"))
                .AddDbContext<AppDbContext>((services, options) =>
                {
                    var dbOptions = services.GetRequiredService<IOptions<DbOptions>>().Value;
                    options.UseSqlServer(dbOptions.OMSDB);
                })
                .AddDbContext<SCMDbContext>((services, options) =>
                {
                    var dbOptions = services.GetRequiredService<IOptions<DbOptions>>().Value;
                    options.UseOracle(dbOptions.SCMDB_TEST);
                })
                .AddScoped<IDbContext, Data.Dapper.DbContext>()
                .AddScoped<IDbService, DbService>()
                .AddTransient<IApiService, ApiService>()
                .AddScoped<IUserSessionCache, UserSessionCache>()
                .AddScoped<IUserContext, UserContext>()
                .AddSingleton(typeof(IMemoryCacheProvider<,>), typeof(MemoryCacheProvider<,>))
                .AddTransient<IRfcRequestBuilder, RfcRequestBuilder>()
                .AddTransient<IRfcExecutor, RfcExecutor>()
                .AddScoped(typeof(IRepository<>), typeof(Repository<>))
                .AddScoped<ISCMRepository, SCMRepository>()
                .AddScoped<IMenuRepository, MenuRepository>();

            var strategyTypes = Assembly.GetExecutingAssembly().GetTypes()
                .Where(t => t.IsClass && !t.IsAbstract && t.GetInterfaces().Contains(typeof(IDNDataStrategy)));

            foreach (var type in strategyTypes)
            {
                services.AddSingleton(typeof(IDNDataStrategy), type);
            }

            return services;
        }
    }
}
