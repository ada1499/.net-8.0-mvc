﻿using Domain.Models.Entities;
using Domain.Services.Interfaces;
using Microsoft.Extensions.Caching.Memory;

namespace Infrastructure.Cache
{
    internal sealed class UserSessionCache(IMemoryCacheProvider<string, UserSessionInfo> cache) : IUserSessionCache
    {
        private readonly IMemoryCacheProvider<string, UserSessionInfo> _cache = cache;
        private readonly MemoryCacheEntryOptions _options = new()
        {
            SlidingExpiration = TimeSpan.FromMinutes(30),
            Size = 1,
            Priority = CacheItemPriority.Low
        };

        public void UpdateUserSession(string username, string ipAddress)
        {
            var session = new UserSessionInfo(username, ipAddress);
            _cache.Set(username, session, _options);
        }

        public UserSessionInfo? GetSession(string username)
            => _cache.TryGetValue(username, out var value) ? value : null;

        public void RemoveSession(string username) => _cache.Remove(username);
    }
}
