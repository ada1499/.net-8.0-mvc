﻿using Domain.Services.Interfaces;
using Microsoft.Extensions.Caching.Memory;
using System.Diagnostics.CodeAnalysis;

namespace Infrastructure.Cache
{
    internal sealed class MemoryCacheProvider<TKey, TValue>(IMemoryCache cache) : IMemoryCacheProvider<TKey, TValue>
    {
        private readonly IMemoryCache _cache = cache;
        private readonly MemoryCacheEntryOptions _options = new()
        {
            AbsoluteExpirationRelativeToNow = TimeSpan.FromMinutes(15),
            Size = 1,
            Priority = CacheItemPriority.Low
        };

        public async Task<TValue?> GetOrCreateAsync(TKey key, Func<Task<TValue>> factory)
            => await _cache.GetOrCreateAsync(key!, async entry =>
            {
                entry.SetOptions(_options);
                return await factory();
            });

        public void Set(TKey key, TValue value, MemoryCacheEntryOptions? options = null)
        {
            options ??= new MemoryCacheEntryOptions();
            _cache.Set(key!, value, options);
        }

        public bool TryGetValue(TKey key, [MaybeNullWhen(false)] out TValue value)
            => _cache.TryGetValue(key!, out value);

        public void Remove(TKey key) => _cache.Remove(key!);
    }
}
