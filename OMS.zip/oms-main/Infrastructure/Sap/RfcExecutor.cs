﻿using Domain.Models.Entities.Rfc;
using Domain.Services.Interfaces;
using Domain.Services.Rfc;

namespace Infrastructure.Sap
{
    internal sealed class RfcExecutor(IApiService apiService) : IRfcExecutor
    {
        private readonly IApiService _apiService = apiService;
        public async Task<RfcResponse> CallRfcAsync(RfcRequest rfcRequest)
            => await _apiService.SendAsync<RfcResponse>("SapApi", HttpMethod.Post, rfcRequest);
    }
}
