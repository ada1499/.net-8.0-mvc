﻿using Domain.Models.Entities.Rfc;
using Domain.Services.Rfc;

namespace Infrastructure.Sap
{
    internal sealed class RfcRequestBuilder : IRfcRequestBuilder
    {
        private string? _funcName, _client, _systemNumber, _language, _systemID, _logonGroup, _appServerHost, _messageServerHost;
        private readonly Dictionary<string, string> _inValue = new();
        private readonly Dictionary<string, List<Dictionary<string, string>>> _inTable = new();

        public IRfcRequestBuilder WithFunction(string funcName)
        {
            _funcName = funcName;
            return this;
        }

        public IRfcRequestBuilder WithClient(string client)
        {
            _client = client;
            return this;
        }

        public IRfcRequestBuilder WithSystemNumber(string systemNumber)
        {
            _systemNumber = systemNumber;
            return this;
        }

        public IRfcRequestBuilder WithLanguage(string language)
        {
            _language = language;
            return this;
        }

        public IRfcRequestBuilder WithSystemID(string systemID)
        {
            _systemID = systemID;
            return this;
        }

        public IRfcRequestBuilder WithLogonGroup(string logonGroup)
        {
            _logonGroup = logonGroup;
            return this;
        }

        public IRfcRequestBuilder WithAppServerHost(string appServerHost)
        {
            _appServerHost = appServerHost;
            return this;
        }

        public IRfcRequestBuilder WithMessageServerHost(string messageServerHost)
        {
            _messageServerHost = messageServerHost;
            return this;
        }

        public IRfcRequestBuilder AddInputValue(string key, string value)
        {
            _inValue[key] = value;
            return this;
        }

        public IRfcRequestBuilder AddInputTable(string table, List<Dictionary<string, string>> rows)
        {
            _inTable[table] = new(rows);
            return this;
        }

        public RfcRequest Build() => new(
            _funcName ?? throw new ArgumentNullException(nameof(_funcName)),
            _client ?? throw new ArgumentNullException(nameof(_client)),
            _systemNumber ?? throw new ArgumentNullException(nameof(_systemNumber)),
            _language,
            _systemID,
            _logonGroup,
            _appServerHost,
            _messageServerHost,
            new(_inValue, _inTable)
        );
    }
}
