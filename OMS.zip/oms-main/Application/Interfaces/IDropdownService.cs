﻿using Microsoft.AspNetCore.Mvc.Rendering;
namespace Application.Interfaces
{
    public interface IDropdownService
    {
        Task<Dictionary<string, IEnumerable<SelectListItem>>?> GetDropDownAsync(Type entityType);
    }
}
