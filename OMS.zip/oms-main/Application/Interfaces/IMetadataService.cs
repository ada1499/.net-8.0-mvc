﻿using Domain.Models.Aggregates.Menu;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace Application.Interfaces
{
    public interface IMetadataService
    {
        Task<List<ColumnInfo>> GetColumnMetadataAsync<T>() where T : class;
        Task<MenuViewModel?> GetMenuMetadataAsync(MenuAggregate menuAggregate);
        Task<Dictionary<string, IEnumerable<SelectListItem>>?> GetDropdownMetaAsync(Type entityType, Func<Task<Dictionary<string, IEnumerable<SelectListItem>>>> factory);
    }
}
