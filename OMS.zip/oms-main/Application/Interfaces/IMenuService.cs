﻿namespace Application.Interfaces
{
    public interface IMenuService
    {
        Task<MenuViewModel?> GetSidebarMenuAsync();
    }
}
