﻿namespace Application.Interfaces
{
    public interface IDataExecutorService
    {
        Task<ViewModel<T>> GetModelDataAsync<T>(string spName, object? parameters = null, bool isProcedure = false) where T : class;
        Task<ViewModel<T>> GetModelDataAsync<T>(IEnumerable<T> data) where T : class;
        Task<ViewModel<T>> GetFuncJsonParamProcedureModelDataAsync<T>(string spName, string funcName, object? request = null) where T : class;
        Task<IEnumerable<T>> GetDataAsync<T>(string spName, object? parameters = null, bool isProcedure = false) where T : class;
        Task<IEnumerable<IDictionary<string, object>>> ExecuteDataAsync(string spName, object? parameters = null, bool isProcedure = false);
        Task<IEnumerable<IDictionary<string, object>>> ExecuteFuncJsonParamProcedureAsync(string spName, string funcName, object? request = null);
    }
}
