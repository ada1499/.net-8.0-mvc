﻿using Domain.Models.Entities.OMS;

namespace Application.Interfaces.OMS
{
    public interface ILaneConfigService
    {
        Task<IEnumerable<Lane_Config>> GetLane_ConfigsAsync(OMS_LANE_CONFIG_Search? request = null);
        Task UpdateLane_ConfigsAsync(List<Lane_Config> configs);
        Task AddLane_ConfigsAsync(List<Lane_Config> configs);
    }
}
