﻿namespace Application.Interfaces.OMS
{
    public interface ICatchSCMData
    {
        Task CatchScmPoAsync();
    }
}
