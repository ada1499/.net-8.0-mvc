﻿using Domain.Models.Entities.OMS;

namespace Application.Interfaces.OMS
{
    public interface IBU_PF_ConfigService
    {
        Task<IEnumerable<BU_PF_Config>> GetBU_PF_ConfigAsync(OMS_BU_PF_CONFIG_Search? request = null);
        Task AddBU_PF_ConfigAsync(List<BU_PF_Config> request);
    }
}
