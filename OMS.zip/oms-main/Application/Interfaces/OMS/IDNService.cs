﻿namespace Application.Interfaces.OMS
{
    public interface IDNService
    {
        Task CreateDNAsync(List<OMS_DN_Request> request);
        Task DeleteDNAsync(List<OMS_DN_DELETE_Request> request);
    }
}
