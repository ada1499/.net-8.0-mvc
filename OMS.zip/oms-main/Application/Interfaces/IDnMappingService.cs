﻿using Domain.Models.Entities.OMS;

namespace Application.Interfaces
{
    public interface IDnMappingService
    {
        Task<IEnumerable<DNMapping>> GetDNMappingAsync(OMS_DN_MAPPING_Search? request = null);
    }
}
