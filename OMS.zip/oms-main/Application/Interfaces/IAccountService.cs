﻿namespace Application.Interfaces
{
    public interface IAccountService
    {
        void Login(string username, string ip);
    }
}
