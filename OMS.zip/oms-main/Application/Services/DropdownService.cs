﻿using Domain.Models.Entities.OMS;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Collections.Concurrent;
using System.Linq.Expressions;
using System.Reflection;

namespace Application.Services
{
    internal sealed class DropdownService(IServiceProvider serviceProvider, IMetadataService metadataService) : IDropdownService
    {
        private readonly IServiceProvider _serviceProvider = serviceProvider;
        private readonly IMetadataService _metadataService = metadataService;
        private static readonly ConcurrentDictionary<Type, Func<object, Task<Dictionary<string, IEnumerable<SelectListItem>>>>> _dropdownResolvers = new();

        public async Task<Dictionary<string, IEnumerable<SelectListItem>>?> GetDropDownAsync(Type searchType)
        {
            var entityType = GetEntityTypeFromSearchModel(searchType);
            if (entityType == null) return null;

            return await _metadataService.GetDropdownMetaAsync(entityType, async () =>
            {
                if (!_dropdownResolvers.TryGetValue(entityType, out var resolver))
                {
                    resolver = CreateResolver(entityType);
                    _dropdownResolvers[entityType] = resolver;
                }

                var repo = GetRepository(entityType);
                return await resolver(repo);
            });
        }

        private Type? GetEntityTypeFromSearchModel(Type searchModelType)
        {
            var attr = searchModelType.GetCustomAttribute<SearchForEntityAttribute>();
            return attr?.EntityType;
        }

        private object GetRepository(Type type)
        {
            var repoType = typeof(IRepository<>).MakeGenericType(type);
            return _serviceProvider.GetRequiredService(repoType);
        }

        private Func<object, Task<Dictionary<string, IEnumerable<SelectListItem>>>> CreateResolver(Type type)
            => async repoObj => type switch {
                _ when type == typeof(RTS_PROCESS) => new()
                {
                    ["Plant"] = await CreateItems((IRepository<RTS_PROCESS>)repoObj, x => x.F_PLANT),
                    ["VendorCode"] = await CreateItems((IRepository<RTS_PROCESS>)repoObj, x => x.F_VENDORCODE),
                    ["POType"] = await CreateItems((IRepository<RTS_PROCESS>)repoObj, x => x.F_POTYPE)
                },
                _ when type == typeof(RTS_MAIN) => new()
                {
                    ["ShipTo"] = await CreateItems((IRepository<RTS_MAIN>)repoObj, x => x.SHIP_TO_NAME),
                    ["ShipFrom"] = await CreateItems((IRepository<RTS_MAIN>)repoObj, x => x.SHIP_FROM_LOCATION)
                },
                _ when type == typeof(Lane_Config) => new()
                {
                    ["SHIP_FROM"] = await CreateItems((IRepository<Lane_Config>)repoObj, x => x.SHIP_FROM),
                    ["SHIP_TO"] = await CreateItems((IRepository<Lane_Config>)repoObj, x => x.SHIP_TO),
                    ["SHIP_METHOD"] = await CreateItems((IRepository<Lane_Config>)repoObj, x => x.SHIP_METHOD),
                    ["SENDER_DUNS_NUMBER"] = await CreateItems((IRepository<Lane_Config>)repoObj, x => x.SENDER_DUNS_NUMBER)
                },
                _ when type == typeof(DNMapping) => new()
                {
                    ["SHIP_FROM"] = await CreateItems((IRepository<DNMapping>)repoObj, x => x.SHIP_FROM),
                    ["SHIP_TO"] = await CreateItems((IRepository<DNMapping>)repoObj, x => x.SHIP_TO)
                },
                _ => new Dictionary<string, IEnumerable<SelectListItem>>()
            };

        private static async Task<IEnumerable<SelectListItem>> CreateItems<T>(IRepository<T> repo, Expression<Func<T, string>> selector) where T : class
            => (await repo.GetDistinctValuesAsync(selector))
                .Select(x => new SelectListItem(x, x));
    }
}
