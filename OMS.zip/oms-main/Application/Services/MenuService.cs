﻿namespace Application.Services
{
    internal sealed class MenuService(IMenuRepository menuRepository, IMetadataService metadataService) : IMenuService
    {
        private readonly IMenuRepository _menuRepository = menuRepository;
        private readonly IMetadataService _metadataService = metadataService;

        public async Task<MenuViewModel?> GetSidebarMenuAsync()
        {
            var menu = await _menuRepository.GetWithGroupAsync(1);
            if (menu == null) return null;

            return await _metadataService.GetMenuMetadataAsync(menu);
        }
    }
}
