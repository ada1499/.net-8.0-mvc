﻿using Domain.Models.Aggregates.Menu;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.ComponentModel;
using System.Reflection;

namespace Application.Services
{
    internal sealed class MetadataService(
        IMemoryCacheProvider<Type, List<ColumnInfo>> columnCacheProvider,
        IMemoryCacheProvider<string, MenuViewModel> menuCacheProvider,
        IMemoryCacheProvider<string, Dictionary<string, IEnumerable<SelectListItem>>> dropdownCacheProvider) : IMetadataService
    {
        private readonly IMemoryCacheProvider<Type, List<ColumnInfo>> _columnCacheProvider = columnCacheProvider;
        private readonly IMemoryCacheProvider<string, MenuViewModel> _menuCacheProvider = menuCacheProvider;
        private readonly IMemoryCacheProvider<string, Dictionary<string, IEnumerable<SelectListItem>>> _dropdownCacheProvider = dropdownCacheProvider;

        public async Task<List<ColumnInfo>> GetColumnMetadataAsync<T>() where T : class
            => await _columnCacheProvider.GetOrCreateAsync(
                    typeof(T),
                    () => Task.Run(() => ExtractColumnMetadata<T>())
                ) ?? new List<ColumnInfo>();

        private static List<ColumnInfo> ExtractColumnMetadata<T>()
            => typeof(T).GetProperties()
                .Select(p => new ColumnInfo(
                    p.Name,
                    p.GetCustomAttribute<DisplayNameAttribute>()?.DisplayName ?? p.Name,
                    p.PropertyType.Name)
                ).ToList();

        public async Task<MenuViewModel?> GetMenuMetadataAsync(MenuAggregate menuAggregate)
        {
            var cacheKey = $"{typeof(MenuAggregate).FullName}_{menuAggregate.GetHashCode()}";

            return await _menuCacheProvider.GetOrCreateAsync(
                cacheKey,
                () => Task.FromResult(ExtractMenuMetadata(menuAggregate)));
        }

        private static MenuViewModel ExtractMenuMetadata(MenuAggregate menuAggregate)
            => new MenuViewModel
            (
                menuAggregate.MenuGroups
                    .OrderBy(g => g.DisplayOrder)
                    .Select(g => new MenuGroupViewModel
                    (
                        g.GroupName,
                        g.Action,
                        g.DisplayOrder,
                        g.MenuItems
                            .OrderBy(i => i.DisplayOrder)
                            .Select(i => new MenuItemViewModel
                            (
                                i.Text,
                                i.Action,
                                i.Controller,
                                i.DisplayOrder
                            )).ToList()
                    )).ToList()
            );

        public async Task<Dictionary<string, IEnumerable<SelectListItem>>?> GetDropdownMetaAsync(Type entityType, Func<Task<Dictionary<string, IEnumerable<SelectListItem>>>> factory)
            => await _dropdownCacheProvider.GetOrCreateAsync($"Dropdown_{entityType.Name}", factory);
    }
}
