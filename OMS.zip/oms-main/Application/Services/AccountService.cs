﻿namespace Application.Services
{
    internal sealed class AccountService(IUserSessionCache cache) : IAccountService
    {
        private readonly IUserSessionCache _cache = cache;

        public void Login(string username ,string ip)
        {
            _cache.UpdateUserSession(username!, ip!);
        }
    }
}
