﻿using Domain.Models.Entities.OMS;

namespace Application.Services.OMS
{
    internal sealed class LaneConfigService(IRepository<Lane_Config> repo) : ILaneConfigService
    {
        private readonly IRepository<Lane_Config> _repo = repo;

        public async Task<IEnumerable<Lane_Config>> GetLane_ConfigsAsync(OMS_LANE_CONFIG_Search? request = null)
            => await _repo.GetAsync(request == null 
                ? _ => true
                : x =>
                    (string.IsNullOrWhiteSpace(request.SHIP_FROM) || x.SHIP_FROM == request.SHIP_FROM) &&
                    (string.IsNullOrWhiteSpace(request.SHIP_TO) || x.SHIP_TO == request.SHIP_TO) &&
                    (string.IsNullOrWhiteSpace(request.SHIP_METHOD) || x.SHIP_METHOD == request.SHIP_METHOD) &&
                    (string.IsNullOrWhiteSpace(request.SENDER_DUNS_NUMBER) || x.SENDER_DUNS_NUMBER == request.SENDER_DUNS_NUMBER)
            );

        public async Task UpdateLane_ConfigsAsync(List<Lane_Config> request)
            => await _repo.UpdateAsync(request);

        public async Task AddLane_ConfigsAsync(List<Lane_Config> request)
            => await _repo.AddAsync(request);
    }
}
