﻿using Domain.Models.Entities.OMS;

namespace Application.Services.OMS
{
    internal sealed class CatchSCMData(ISCMRepository scmRepository, IRepository<RTS_PROCESS> rtsRepo) : ICatchSCMData
    {
        private readonly ISCMRepository _scmRepository = scmRepository;
        private readonly IRepository<RTS_PROCESS> _rtsRepo = rtsRepo;

        public async Task CatchScmPoAsync()
        {
            await GetBlankPoCommitAsync();
            // await GetStandardPoCommitAsync();
        }

        private async Task GetBlankPoCommitAsync()
        {
            var blankPos = await _scmRepository.GetBlankPoAsync();
            
            var data =  blankPos
                .Select(b => new RTS_PROCESS(
                    default,
                    b.F_TRACKNO,
                    b.F_PO,
                    b.F_ITEM,
                    b.F_NEWLINE,
                    b.F_PN,
                    DateTime.Parse(b.F_COMMITDELIVERYDATE),
                    DateTime.Parse(b.F_ETD),
                    b.F_PLANT,
                    b.F_COMMITDELIVERYQTY,
                    default,
                    default,
                    b.F_POTYPE,
                    default,
                    default,
                    b.F_VENDORCODE,
                    default,
                    b.BlankPoLine.ITEM_DESCRIPTION
                )).ToList();

            await _rtsRepo.AddAsync(data);
            await _scmRepository.BulkUpdateBlankPoAsync(blankPos);
        }

        private async Task GetStandardPoCommitAsync()
        {
            var standardPos = await _scmRepository.GetStandardPoAsync();

            var data = standardPos
                .Select(b => new RTS_PROCESS(
                    default,
                    b.F_TRACKNO,
                    b.F_PO,
                    b.F_ITEM,
                    b.F_NEWLINE,
                    b.F_PN,
                    DateTime.Parse(b.F_COMMITDELIVERYDATE),
                    DateTime.Parse(b.F_ETD),
                    b.F_PLANT,
                    b.F_COMMITDELIVERYQTY,
                    default,
                    default,
                    b.F_POTYPE,
                    default,
                    default,
                    b.F_VENDORCODE,
                    default,
                    b.StandardPoLine.ITEM_DESCRIPTION
                )).ToList();

            await _rtsRepo.AddAsync(data);
            await _scmRepository.BulkUpdateStandardPoAsync(standardPos);
        }
    }
}
