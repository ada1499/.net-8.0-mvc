﻿using Domain.Models.Entities.OMS;

namespace Application.Services.OMS
{
    internal sealed class BU_PF_ConfigService(IRepository<BU_PF_Config> repo) : IBU_PF_ConfigService
    {
        private readonly IRepository<BU_PF_Config> _repo = repo;

        public async Task<IEnumerable<BU_PF_Config>> GetBU_PF_ConfigAsync(OMS_BU_PF_CONFIG_Search? request = null)
            => await _repo.GetAsync(request == null
                ? _ => true
                : x => string.IsNullOrWhiteSpace(request.PARTNO) || x.PARTNO == request.PARTNO);

        public async Task AddBU_PF_ConfigAsync(List<BU_PF_Config> request)
            => await _repo.AddAsync(request);
    }
}
