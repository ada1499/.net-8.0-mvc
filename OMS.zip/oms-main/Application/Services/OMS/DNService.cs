﻿using Domain.Models.Entities.OMS;
using Domain.Models.Entities.Rfc;
using Domain.Services.OMS;
using Domain.Services.Rfc;

namespace Application.Services.OMS
{
    internal sealed class DNService(
        IRfcRequestBuilder rfcRequest,
        IRfcExecutor rfcExecutor,
        IDataExecutorService dataExecutor,
        IDbService dbService,
        IRepository<DNInfo> repository,
        IEnumerable<IDNDataStrategy> strategies) : IDNService
    {
        private readonly IRfcRequestBuilder _rfcRequest = rfcRequest;
        private readonly IRfcExecutor _rfcExecutor = rfcExecutor;
        private readonly IDataExecutorService _dataExecutor = dataExecutor;
        private readonly IDbService _dbService = dbService;
        private readonly IRepository<DNInfo> _repository = repository;
        private readonly IEnumerable<IDNDataStrategy> _strategies = strategies;

        public async Task CreateDNAsync(List<OMS_DN_Request> request)
        {
            Validate(request);
            await PrepareDNDataAsync(request);
            await ProcessDNAsync();
        }

        public async Task DeleteDNAsync(List<OMS_DN_DELETE_Request> request)
            => await _dataExecutor.ExecuteFuncJsonParamProcedureAsync("OMS_CREATE_DN", "DELETE_DN", request);

        private void Validate(List<OMS_DN_Request> requests)
        {
            var invalid = requests.Where(r => r.DN_QTY > r.SHIPPED_QUANTITY).ToList();

            if (invalid.Any())
                throw new InvalidOperationException(
                    $"Invalid quantity detected in {invalid.Count} records. First error: DN_QTY={invalid[0].DN_QTY} > SHIPPED_QUANTITY={invalid[0].SHIPPED_QUANTITY}"
                );
        }

        private async Task PrepareDNDataAsync(List<OMS_DN_Request> request)
            => await _dataExecutor.ExecuteFuncJsonParamProcedureAsync("OMS_CREATE_DN", "PREPARE_DN_DATA", request);

        private async Task ProcessDNAsync()
        {
            var records = await _repository.GetAsync(d => d.STATUS == 0);

            foreach (var record in records)
            {
                var strategy = _strategies.FirstOrDefault(s => s.CanHandle(record.IN_FLAG))
                    ?? throw new Exception($"Unknown type of IN_FLAG: {record.IN_FLAG}");

                var dnData = await strategy.GetDataAsync(_dbService, record.IN_FLAG, record.REC_ID);
                var rfcRequest = strategy.BuildRequest(_rfcRequest, record.IN_FLAG, dnData);
                //var rfcReponse = await _rfcExecutor.CallRfcAsync(rfcRequest);
                var rfcReponse = JsonSerializer.Deserialize<RfcResponse>("{\r\n    \"Sratus\": \"success\",\r\n    \"Data\": {\r\n        \"OutputValues\": {\r\n            \"O_DELIVERY_ID\": \"TEST\",\r\n            \"O_DN\": \"TEST\",\r\n            \"O_FLAG\": \"0\",\r\n            \"O_MESSAGE\": \"TEST O_MESSAGE\",\r\n            \"O_SERVLEVL\": \"TEST\",\r\n            \"O_SO\": \"TEST O_SO\"\r\n        }\r\n    }\r\n}");
                var apiData = rfcReponse.Data.OutputValues;
                var dnInfo = MapToDNInfo(apiData, record).UpdateStatus();
                await _repository.UpdateAsync(dnInfo);
            }
            await _repository.SaveChangeAsync();
        }

        public static DNInfo MapToDNInfo(Dictionary<string, string> data, DNInfo dnInfo)
            => dnInfo with
            {
                O_DELIVERY_ID = data[nameof(DNInfo.O_DELIVERY_ID)],
                O_DN = data.GetValueOrDefault(nameof(DNInfo.O_DN)),
                O_FLAG = int.Parse(data[nameof(DNInfo.O_FLAG)]),
                O_MESSAGE = data[nameof(DNInfo.O_MESSAGE)],
                O_SERVLEVL = data[nameof(DNInfo.O_SERVLEVL)],
                O_SO = data.GetValueOrDefault(nameof(DNInfo.O_SO))
            };
    }
}
