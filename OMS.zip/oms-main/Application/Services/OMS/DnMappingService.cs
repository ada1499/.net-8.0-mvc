﻿using Domain.Models.Entities.OMS;

namespace Application.Services.OMS
{
    internal sealed class DnMappingService(IRepository<DNMapping> repo) : IDnMappingService
    {
        private readonly IRepository<DNMapping> _repo = repo;

        public async Task<IEnumerable<DNMapping>> GetDNMappingAsync(OMS_DN_MAPPING_Search? request = null)
            => await _repo.GetAsync(request == null
                ? _ => true
                : x =>
                    (string.IsNullOrWhiteSpace(request.SHIP_FROM) || x.SHIP_FROM == request.SHIP_FROM) &&
                    (string.IsNullOrWhiteSpace(request.SHIP_TO) || x.SHIP_TO == request.SHIP_TO)
            );
    }
}
