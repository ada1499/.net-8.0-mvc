﻿namespace Application.Services
{
    internal sealed class DataExecutorService(IDbService dbService, IMetadataService metadata, IUserContext context) : IDataExecutorService
    {
        private readonly IDbService _dbService = dbService;
        private readonly IMetadataService _metadata = metadata;
        private readonly IUserContext _context = context;

        public async Task<ViewModel<T>> GetModelDataAsync<T>(string spName, object? parameters = null, bool isProcedure = false) where T : class
        {
            var dataTask = _dbService.QueryAsync<T>(spName, parameters, isProcedure);
            var columnsTask = _metadata.GetColumnMetadataAsync<T>();

            await Task.WhenAll(dataTask, columnsTask);

            return new ViewModel<T>(
                columnsTask.Result,
                dataTask.Result.ToList()
            );
        }

        public async Task<ViewModel<T>> GetModelDataAsync<T>(IEnumerable<T> data) where T : class
            => new ViewModel<T>(
                await _metadata.GetColumnMetadataAsync<T>(),
                data.ToList()
            );

        public async Task<ViewModel<T>> GetFuncJsonParamProcedureModelDataAsync<T>(string spName, string funcName, object? request = null) where T : class
        {
            var parameters = BuildFuncJsonParameters(funcName, _context.Username, request);
            return await GetModelDataAsync<T>(spName, parameters, true);
        }

        public async Task<IEnumerable<T>> GetDataAsync<T>(string spName, object? parameters = null, bool isProcedure = false) where T : class
            => await _dbService.QueryAsync<T>(spName, parameters, isProcedure);

        public async Task<IEnumerable<IDictionary<string, object>>> ExecuteDataAsync(string spName, object? parameters = null, bool isProcedure = false)
        {
            var result = await _dbService.QueryAsync<dynamic>(spName, parameters, isProcedure);
            return result.Select(row => (IDictionary<string, object>)row);
        }

        public async Task<IEnumerable<IDictionary<string, object>>> ExecuteFuncJsonParamProcedureAsync(string spName, string funcName, object? request = null)
        {
            var parameters = BuildFuncJsonParameters(funcName, _context.Username, request);
            return await ExecuteDataAsync(spName, parameters, true);
        }

        private static Dictionary<string, object> BuildFuncJsonParameters(string funcName, string userId, object? request = null)
        {
            var parameters = new Dictionary<string, object>
            {
                { "@FUNCTION", funcName },
                { "@USER_ID", userId }
            };

            if (request != null)
            {
                parameters.Add("@JSON", JsonSerializer.Serialize(request));
            }
            return parameters;
        }
    }
}
