﻿namespace Application.Dtos
{
    [AttributeUsage(AttributeTargets.Class)]
    public class SearchForEntityAttribute : Attribute
    {
        public Type EntityType { get; }

        public SearchForEntityAttribute(Type entityType)
        {
            EntityType = entityType;
        }
    }
}
