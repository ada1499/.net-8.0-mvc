﻿namespace Application.Dtos
{
    public record UserSessionInfo(string username, string IpAddress);
}
