﻿using Microsoft.AspNetCore.Mvc.Rendering;

namespace Application.Dtos
{
    public record ViewModel<T>(
        List<ColumnInfo> Columns,
        List<T> Data
    );

    public record ColumnInfo(
        string FieldName,
        string DisplayName,
        string DataType
    );

    public record MenuViewModel(
        List<MenuGroupViewModel> MenuGroups);

    public record MenuGroupViewModel(
        string GroupName,
        string Action,
        int DisplayOrder,
        List<MenuItemViewModel> MenuItems);

    public record MenuItemViewModel(
        string Text,
        string Action,
        string Controller,
        int DisplayOrder);

    public record SearchViewModel(
        Type SearchType,
        string ActionName,
        Dictionary<string, IEnumerable<SelectListItem>>? DropdownOptions = null
    );

    public record ActionViewModel(
        string ActionName,
        string ButtonName,
        string? Type = null,
        string? Title = null,
        string? Message = null,
        string? PayloadActionName = null
    );

    public record StatusViewModel(
        string? Red = null,
        string? Green = null,
        string? Grey = null,
        string? Tan = null);
}
