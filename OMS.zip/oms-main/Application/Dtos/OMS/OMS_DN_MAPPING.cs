﻿using Domain.Models.Entities.OMS;

namespace Application.Dtos.OMS
{
    [SearchForEntity(typeof(DNMapping))]
    public record OMS_DN_MAPPING_Search(
        string? SHIP_FROM,
        string? SHIP_TO);
}
