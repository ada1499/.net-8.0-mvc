﻿using Domain.Models.Entities.OMS;

namespace Application.Dtos.OMS
{
    public record OMS_3B2RTS_PROCESS(
        int FLAG,
        int ID,
        string F_SHIPVIA,
        string F_PLANT,
        string F_VENDORCODE,
        string F_PO,
        string F_ITEM,
        string F_NEWLINE,
        string F_PN,
        DateTime F_ETD,
        DateTime F_COMMITDELIVERYDATE,
        int F_COMMITDELIVERYQTY,
        string F_POTYPE,
        string F_EXPEDITEFLAG,
        string F_PACKTYPE,
        string? F_APPROVALID,
        string? BU,
        string? PRODUCT_FAMILY
    );

    [SearchForEntity(typeof(RTS_PROCESS))]
    public record OMS_3B2RTS_PROCESS_Search(
        string? VendorCode,
        string? Plant,
        DateTime? ETD,
        string? POType,
        string? PN,
        string? PO,
        string? Item,
        string? Line
    );
}
