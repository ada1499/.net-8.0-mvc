﻿using Domain.Common;

namespace Application.Dtos.OMS
{
    public record OMS_DN_Request(
        string? REC_ID,
        string SHIP_FROM,
        string SHIP_TO,
        string SHIP_VIA,
        string PO,
        string PN,
        string ITEM,
        int SHIPPED_QUANTITY,
        int DN_QTY,
        string DELIVERY_ID,
        string CARRIER_CODE,
        Date ETA,
        string PLANT);

    public record OMS_DN_DELETE_Request(
        string REC_ID);
}
