﻿using Domain.Models.Entities.OMS;

namespace Application.Dtos.OMS
{
    public record OMS_3B2RTS_MAIN(
        int FLAG,
        string MESSAGE_ID,
        string SHIP_TO_NAME,
        string SENDER_DUNS_NUMBER,
        string PO,
        string PN,
        int SHIPPED_QUANTITY,
        string? PLANT,
        string SHIP_VIA,
        string ITEM_NUMBER,
        string PO_LINE_NUMBER,
        DateTime ETD,
        DateTime ETA,
        string PACK_TYPE,
        string EXPEDITE_FLAG,
        string? PRODUCTNAME,
        string? BU,
        string? APPROVEID
     );

    [SearchForEntity(typeof(RTS_MAIN))]
    public record OMS_3B2RTS_MAIN_Search(
        string? ShipTo,
        string? PO,
        string? PN,
        string? Item,
        string? Line
    );

    public record OMS_3B2RTS_MAIN_CONFIG(
        int F_ID,
        string SHIP_TO_NAME,
        string SENDER_DUNS_NUMBER,
        string SHIP_VIA,
        string PN,
        DateTime? ETD,
        DateTime? ETA,
        string? BU,
        string? PRODUCTNAME);
}
