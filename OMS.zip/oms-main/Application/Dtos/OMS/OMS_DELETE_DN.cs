﻿namespace Application.Dtos.OMS
{
    public record OMS_DELETE_DN(
        int FLAG,
        string IN_FLAG,
        string DELIVERY_ID,
        string? O_DN,
        string? O_SO,
        int DN_QTY,
        string O_MESSAGE,
        string USER_ID,
        string REC_ID);

    public record OMS_DELETE_DN_Search(
        string? DELIVERY_ID,
        string? O_DN);
}
