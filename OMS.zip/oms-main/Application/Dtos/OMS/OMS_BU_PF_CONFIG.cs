﻿namespace Application.Dtos.OMS
{
    public record OMS_BU_PF_CONFIG_Search(
        string? PARTNO);
}
