﻿namespace Application.Dtos.OMS
{
    public record BlankPoDto(
        string F_TRACKNO,
        string F_PO,
        string F_ITEM,
        string F_NEWLINE,
        string F_PN,
        string F_COMMITDELIVERYDATE,
        string F_ETD,
        string F_PLANT,
        int F_COMMITDELIVERYQTY,
        string F_POTYPE,
        string F_VENDORCODE,
        string ITEM_DESCRIPTION);
}
