﻿using Domain.Models.Entities.OMS;

namespace Application.Dtos.OMS
{
    public record OMS_3B18_MAIN(
        int FLAG,
        string SHIP_FROM,
        string SHIP_TO,
        string SHIP_VIA,
        string PO,
        string PN,
        string ITEM,
        string LINE,
        int? SHIPPED_QUANTITY,
        int? DN_QTY,
        string? DN_NO,
        string? DELIVERY_ID,
        string? EXPEDITE,
        string? CARRIER_CODE,
        DateTime ETA,
        string? DN_MESSAGE,
        string? SO,
        string? PLANT,
        string? REC_ID
    );

    [SearchForEntity(typeof(RTS_MAIN))]
    public record OMS_3B18_MAIN_Search(
        string? ShipFrom,
        string? ShipTo,
        DateTime? ETA,
        string? PN,
        string? PO,
        string? Item,
        string? Line
    );
}
