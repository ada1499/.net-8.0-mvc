﻿using Domain.Models.Entities.OMS;

namespace Application.Dtos.OMS
{
    [SearchForEntity(typeof(Lane_Config))]
    public record OMS_LANE_CONFIG_Search(
        string? SHIP_FROM,
        string? SHIP_TO,
        string? SHIP_METHOD,
        string? SENDER_DUNS_NUMBER);
}
