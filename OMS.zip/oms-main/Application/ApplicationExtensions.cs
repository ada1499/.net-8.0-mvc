﻿using Application.Services;
using Application.Services.OMS;

namespace Application
{
    public static class ApplicationExtensions
    {
        public static IServiceCollection AddApplication(this IServiceCollection services)
        {
            services
                .AddScoped<IAccountService, AccountService>()
                .AddScoped<IDataExecutorService, DataExecutorService>()
                .AddScoped<IMetadataService, MetadataService>()
                .AddScoped<IMenuService, MenuService>()
                .AddScoped<IDropdownService, DropdownService>()
                .AddScoped<IDNService, DNService>()
                .AddScoped<ICatchSCMData, CatchSCMData>()
                .AddScoped<ILaneConfigService, LaneConfigService>()
                .AddScoped<IBU_PF_ConfigService, BU_PF_ConfigService>()
                .AddScoped<IDnMappingService, DnMappingService>();

            return services;
        }
    }
}
