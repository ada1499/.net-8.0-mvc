﻿global using Application.Dtos;
global using Application.Dtos.OMS;
global using Application.Interfaces;
global using Application.Interfaces.OMS;
global using Domain.Services.Interfaces;
global using System.Data;
global using System.Text.Json;
