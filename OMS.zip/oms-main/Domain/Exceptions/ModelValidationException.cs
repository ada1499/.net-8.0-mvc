﻿using Microsoft.AspNetCore.Mvc.ModelBinding;

namespace Domain.Exceptions
{
    public class ModelValidationException : Exception
    {
        public ModelValidationException(ModelStateDictionary modelState) : base()
        {
            Data = modelState
                .Where(e => e.Value?.Errors.Count > 0)
                .ToDictionary(
                    e => e.Key,
                    e => e.Value!.Errors.Select(error => error.ErrorMessage).ToArray()
                );
        }

        public override Dictionary<string, string[]> Data { get; }
    }
}
