﻿using System.Net;

namespace Domain.Exceptions
{
    public class ApiException : Exception
    {
        public HttpStatusCode StatusCode { get; }
        public string? ResponseContent { get; }

        public ApiException(string message, HttpStatusCode statusCode, string? response = null)
            : base(message)
        {
            StatusCode = statusCode;
            ResponseContent = response;
        }
    }
}
