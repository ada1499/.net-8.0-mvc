﻿using System.Text.Json.Serialization;
using System.Text.Json;

namespace Domain.Common
{
    [JsonConverter(typeof(DateJsonConverter))]
    public readonly record struct Date(DateTime Value)
    {
        public Date(string date) : this(DateTime.Parse(date)) { }

        public static implicit operator Date(DateTime dt) => new(dt);
        public static implicit operator DateTime(Date d) => d.Value;

        public override string ToString() => Value.ToString("yyyy-MM-dd");
        public Date AddDays(int days) => new(Value.AddDays(days));
    }

    public class DateJsonConverter : JsonConverter<Date>
    {
        public override Date Read(ref Utf8JsonReader reader, Type type, JsonSerializerOptions options)
            => reader.TokenType == JsonTokenType.Null
                ? default
                : new Date(reader.GetString()!);

        public override void Write(Utf8JsonWriter writer, Date value, JsonSerializerOptions options)
            => writer.WriteStringValue(value.Value == default ? null : value.ToString());
    }
}
