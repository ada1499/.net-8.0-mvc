﻿using Domain.Common;

namespace Domain.Models.ValueObjects.OMS
{
    public record SODN(
        string AUART,
        string VKORG,
        string VTWEG,
        string SPART,
        string VKGRP,
        string VKBUR,
        string KUNAG,
        string KUNNR,
        string BSTKD,
        Date BSTDK,
        Date VDATU,
        string INCO1,
        string INCO2,
        string VSART,
        string SDABW,
        string WERKS,
        string MATNR,
        int KWMENG,
        string LGORT,
        string VSTEL,
        string ROUTE,
        string LIFEX,
        string SERVLEVL);

    public record DNBYPO(
        string EBELN,
        string EBELP,
        string MATNR,
        int MENGE,
        string WERKS,
        string LGORT,
        Date EINDT,
        string INCO1,
        string INCO2,
        string VSART,
        string SDABW,
        string LIFEX,
        string SERVLEVL);
}
