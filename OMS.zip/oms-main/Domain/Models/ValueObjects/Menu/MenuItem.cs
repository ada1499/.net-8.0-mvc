﻿namespace Domain.Models.ValueObjects.Menu
{
    public record MenuItem(
        string Text,
        string Action,
        string Controller,
        int DisplayOrder);
}
