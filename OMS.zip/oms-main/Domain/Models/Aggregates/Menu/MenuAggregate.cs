﻿using Domain.Models.Entities.Menu;

namespace Domain.Models.Aggregates.Menu
{
    public class MenuAggregate
    {
        public int Id { get; set; }
        public required string Name { get; set; }
        public List<MenuGroup> MenuGroups { get; set; } = [];
    }
}
