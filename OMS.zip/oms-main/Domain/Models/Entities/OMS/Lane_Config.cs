﻿namespace Domain.Models.Entities.OMS
{
    public record Lane_Config(
        string SHIP_FROM,
        string SHIP_TO,
        string? SHIP_TO_COMMENTS,
        string? AIRPORT_TO_AIRPORT,
        string SHIP_METHOD,
        string? CARRIER,
        int D2D_ONWAY_DAYS,
        string? COMMENTS,
        DateTime? LAST_EDITDT,
        string SENDER_DUNS_NUMBER,
        string? USER_ID);
}
