﻿namespace Domain.Models.Entities.OMS
{
    public record DNInfo(
        string REC_ID,
        string IN_FLAG,
        string? O_DELIVERY_ID,
        string? O_DN,
        int? O_FLAG,
        string? O_MESSAGE,
        string? O_SERVLEVL,
        string? O_SO,
        int STATUS)
    {
        public DNInfo UpdateStatus() => this with { STATUS = string.IsNullOrWhiteSpace(O_DN) ? -1 : 1 };
    }
}
