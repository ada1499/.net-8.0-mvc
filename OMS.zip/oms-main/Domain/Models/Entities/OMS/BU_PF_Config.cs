﻿namespace Domain.Models.Entities.OMS
{
    public record BU_PF_Config(
        string PARTNO,
        string BU,
        string PRODUCT_FAMILY,
        string? LASTEDITBY,
        DateTime LASTEDITDT);
}
