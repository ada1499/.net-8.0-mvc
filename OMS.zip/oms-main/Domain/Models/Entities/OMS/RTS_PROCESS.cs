﻿namespace Domain.Models.Entities.OMS
{
    public record RTS_PROCESS(
        int ID,
        string F_TRACKNO,
        string F_PO,
        string F_ITEM,
        string F_NEWLINE,
        string F_PN,
        DateTime F_COMMITDELIVERYDATE,
        DateTime F_ETD,
        string F_PLANT,
        int F_COMMITDELIVERYQTY,
        string F_SHIPVIA,
        string F_EXPEDITEFLAG,
        string F_POTYPE,
        string? F_BU,
        string? F_PRODUCTNAME,
        string F_VENDORCODE,
        string F_SENDFLAG,
        string ITEM_DESCRIPTION);
}
