﻿namespace Domain.Models.Entities.SCM
{
    public record BlankPoCommit
    {
        public required string ID { get; set; }
        public required string F_TRACKNO { get; set; }
        public required string F_PO { get; set; }
        public required string F_ITEM { get; set; }
        public required string F_NEWLINE { get; set; }
        public required string F_PN { get; set; }
        public required string F_COMMITDELIVERYDATE { get; set; }
        public required string F_ETD { get; set; }
        public required string F_PLANT { get; set; }
        public int F_COMMITDELIVERYQTY { get; set; }
        public required string F_POTYPE { get; set; }
        public required string F_VENDORCODE { get; set; }
        public required string F_LINESTATUS { get; set; }
        public required string F_SENDFLAG { get; set; }
        public required BlankPoLine BlankPoLine { get; set; }
    }

    public record BlankPoLine(
        string ID,
        string ITEM_DESCRIPTION);
}
