﻿namespace Domain.Models.Entities
{
    public record UserSessionInfo(
        string Username,
        string IpAddress,
        DateTime LastActiveTime = default)
    {
        public DateTime LastActiveTime { get; private set; } = LastActiveTime == default
            ? DateTime.UtcNow
            : LastActiveTime;

        public void RefreshActivity() => LastActiveTime = DateTime.UtcNow;
    }
}
