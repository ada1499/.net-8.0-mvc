﻿namespace Domain.Models.Entities.Rfc
{
    public record RfcRequest(
        string FuncName,
        string Client,
        string SystemNumber,
        string? Language,
        string? SystemID,
        string? LogonGroup,
        string? AppServerHost,
        string? MessageServerHost,
        RfcRequestInput? Input
    );

    public record RfcRequestInput(
        Dictionary<string, string> InValue,
        Dictionary<string, List<Dictionary<string, string>>> Table
    );
}
