﻿namespace Domain.Models.Entities.Rfc
{
    public record RfcResponse(string Status, RfcData Data);
    public record RfcData(Dictionary<string, string> OutputValues, Dictionary<string, List<Dictionary<string, string>>> OutputTables);
}
