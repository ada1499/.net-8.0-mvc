﻿using Domain.Models.ValueObjects.Menu;

namespace Domain.Models.Entities.Menu
{
    public class MenuGroup
    {
        public int Id { get; set; }
        public required string GroupName { get; set; }
        public required string Action { get; set; }
        public int DisplayOrder { get; set; }
        public List<MenuItem> MenuItems { get; set; } = [];

        public void AddMenuItem(MenuItem item)
        {
            if (item == null) throw new ArgumentNullException(nameof(item));
            MenuItems.Add(item);
        }
    }
}
