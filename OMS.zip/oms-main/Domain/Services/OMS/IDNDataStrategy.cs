﻿using Domain.Models.Entities.Rfc;
using Domain.Services.Interfaces;
using Domain.Services.Rfc;

namespace Domain.Services.OMS
{
    public interface IDNDataStrategy
    {
        bool CanHandle(string flag);
        string TableName { get; }
        Task<object> GetDataAsync(IDbService dbService, string flag, string recId);
        RfcRequest BuildRequest(IRfcRequestBuilder requestBuilder, string flag, object data);
    }
}
