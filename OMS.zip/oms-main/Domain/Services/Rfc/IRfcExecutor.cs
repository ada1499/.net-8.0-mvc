﻿using Domain.Models.Entities.Rfc;

namespace Domain.Services.Rfc
{
    public interface IRfcExecutor
    {
        Task<RfcResponse> CallRfcAsync(RfcRequest rfcRequest);
    }
}
