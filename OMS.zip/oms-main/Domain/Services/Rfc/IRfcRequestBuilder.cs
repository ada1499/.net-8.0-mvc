﻿using Domain.Models.Entities.Rfc;

namespace Domain.Services.Rfc
{
    public interface IRfcRequestBuilder
    {
        IRfcRequestBuilder WithFunction(string funcName);
        IRfcRequestBuilder WithClient(string client);
        IRfcRequestBuilder WithSystemNumber(string systemNumber);
        IRfcRequestBuilder WithLanguage(string language);
        IRfcRequestBuilder WithSystemID(string systemID);
        IRfcRequestBuilder WithLogonGroup(string logonGroup);
        IRfcRequestBuilder WithAppServerHost(string appServerHost);
        IRfcRequestBuilder WithMessageServerHost(string messageServerHost);
        IRfcRequestBuilder AddInputValue(string key, string value);
        IRfcRequestBuilder AddInputTable(string table, List<Dictionary<string, string>> rows);
        RfcRequest Build();
    }
}
