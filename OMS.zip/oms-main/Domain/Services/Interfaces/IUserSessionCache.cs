﻿using Domain.Models.Entities;

namespace Domain.Services.Interfaces
{
    public interface IUserSessionCache
    {
        void UpdateUserSession(string username, string ipAddress);
        UserSessionInfo? GetSession(string username);
        void RemoveSession(string username);
    }
}
