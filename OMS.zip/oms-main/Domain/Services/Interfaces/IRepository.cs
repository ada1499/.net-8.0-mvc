﻿using System.Linq.Expressions;

namespace Domain.Services.Interfaces
{
    public interface IRepository<T> where T : class
    {
        Task<IEnumerable<T>> GetAllAsync();
        Task<IEnumerable<T>> GetDistinctAllAsync();
        Task<T> GetByIdAsync(int id);
        Task<IEnumerable<TResult>> GetDistinctValuesAsync<TResult>(Expression<Func<T, TResult>> selector, Expression<Func<T, bool>>? predicate = null);
        Task<IEnumerable<T>> GetAsync(Expression<Func<T, bool>> expression);
        Task<IEnumerable<T>> GetDistinctAsync(Expression<Func<T, bool>> expression);
        Task AddAsync(T eneity);
        Task AddAsync(IEnumerable<T> entities);
        Task UpdateAsync(T entity);
        Task UpdateAsync(IEnumerable<T> entities);
        Task DeleteByIdAsync(int id);
        Task BulkDeleteAsync(IEnumerable<T> entities);
        Task<bool> SaveChangeAsync();
        Task<bool> BulkSaveChangeAsync();
    }
}
