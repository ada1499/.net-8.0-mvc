﻿using Domain.Models.Entities.SCM;

namespace Domain.Services.Interfaces
{
    public interface ISCMRepository
    {
        Task<IEnumerable<BlankPoCommit>> GetBlankPoAsync();
        Task<IEnumerable<StandardPoCommit>> GetStandardPoAsync();
        Task BulkUpdateBlankPoAsync(IEnumerable<BlankPoCommit> entities);
        Task BulkUpdateStandardPoAsync(IEnumerable<StandardPoCommit> entities);
    }
}
