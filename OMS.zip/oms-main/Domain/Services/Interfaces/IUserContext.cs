﻿namespace Domain.Services.Interfaces
{
    public interface IUserContext
    {
        string Username { get; }
    }
}
