﻿namespace Domain.Services.Interfaces
{
    public interface IApiService
    {
        Task<TResponse> SendAsync<TResponse>(
            string endpointName,
            HttpMethod method,
            object? requestData = null,
            Dictionary<string, string>? parameters = null,
            CancellationToken ct = default);
    }
}
