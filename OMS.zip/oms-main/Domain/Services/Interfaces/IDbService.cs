﻿namespace Domain.Services.Interfaces
{
    public interface IDbService
    {
        Task<IEnumerable<T>> QueryAsync<T>(string command, object? parameters = null, bool isStoredProcedure = false);
        Task<int> ExecuteAsync(string command, object? parameters = null, bool isStoredProcedure = false);
    }
}
