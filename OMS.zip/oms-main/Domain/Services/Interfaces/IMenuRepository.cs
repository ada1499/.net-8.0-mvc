﻿using Domain.Models.Aggregates.Menu;

namespace Domain.Services.Interfaces
{
    public interface IMenuRepository
    {
        Task<MenuAggregate?> GetByIdAsync(int id);
        Task<MenuAggregate?> GetWithGroupAsync(int id);
        Task AddAsync(MenuAggregate menu);
        Task UpdateAsync(MenuAggregate menu);
    }
}
