﻿using Microsoft.Extensions.Caching.Memory;
using System.Diagnostics.CodeAnalysis;

namespace Domain.Services.Interfaces
{
    public interface IMemoryCacheProvider<TKey, TValue>
    {
        Task<TValue?> GetOrCreateAsync(TKey key, Func<Task<TValue>> factory);
        void Set(TKey key, TValue value, MemoryCacheEntryOptions? options = null);
        bool TryGetValue(TKey key, [MaybeNullWhen(false)] out TValue value);
        void Remove(TKey key);
    }
}
