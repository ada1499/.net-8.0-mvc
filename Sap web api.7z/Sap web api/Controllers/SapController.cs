﻿using System;
using System.Web.Http;
using SapService.Models;
using System.Threading.Tasks;
using SapService.Services;

namespace SapService.Controllers
{
    public class SapController : ApiController
    {
        private readonly IRfcService _rfcService;

        public SapController(IRfcService rfcService)
            => _rfcService = rfcService;

        [HttpPost]
        public async Task<IHttpActionResult> ExcuteRfc([FromBody] RfcRequest request)
        {
            try
            {
                var result = await _rfcService.ExecuteRfcAsync(request);
                return Ok(new { Success = true, Data = result });
            }
            catch (Exception ex)
            {
                return InternalServerError(ex);
            }
        }
    }
}