﻿using System;
using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json;
using System.Linq;

namespace SapService.Services
{
    internal sealed class RfcConfigReader : IRfcConfigReader
    {
        private readonly Dictionary<string, RfcConfig> _configs;

        public RfcConfigReader()
        {
            var configPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "App_Data", "appsetting.json");
            var json = File.ReadAllText(configPath);
            var collection = JsonConvert.DeserializeObject<RfcConfigCollection>(json);

            _configs = collection.Configurations
                .SelectMany(dict => dict)
                .ToDictionary(kvp => kvp.Key, kvp => kvp.Value);
        }

        public RfcConfig GetConfig(string funcName)
        {
            if (_configs.TryGetValue(funcName, out var config))
                return config;
            throw new KeyNotFoundException($"RFC config for {funcName} not found");
        }
    }
}