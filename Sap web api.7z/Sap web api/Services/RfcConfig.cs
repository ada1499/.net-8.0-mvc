﻿using System;
using System.Collections.Generic;
using SAP.Middleware.Connector;

namespace SapService.Services
{
    public class RfcConfig
    {
        public string Name { get; set; }
        public string User { get; set; }
        public string Password { get; set; }
        public string Client { get; set; }
        public string Language { get; set; } = "EN";
        public string AppServerHost { get; set; }
        public string SystemNumber { get; set; } = "00";
        public string SystemID { get; set; } = "CNP";
        public int PoolSize { get; set; } = 20;
        public TimeSpan IdleTimeout { get; set; } = TimeSpan.FromMinutes(10);

        public RfcConfigParameters ToRfcParameters() => new RfcConfigParameters
        {
            { RfcConfigParameters.Name, Name },
            { RfcConfigParameters.User, User },
            { RfcConfigParameters.Password, Password },
            { RfcConfigParameters.Client, Client },
            { RfcConfigParameters.Language, Language },
            { RfcConfigParameters.AppServerHost, AppServerHost },
            { RfcConfigParameters.SystemNumber, SystemNumber },
            { RfcConfigParameters.SystemID, SystemID },
            { RfcConfigParameters.PoolSize, PoolSize.ToString() },
            { RfcConfigParameters.PoolIdleTimeout, IdleTimeout.TotalSeconds.ToString() }
        };
    }

    public class RfcConfigCollection
    {
        public List<Dictionary<string, RfcConfig>> Configurations { get; set; }
    }
}