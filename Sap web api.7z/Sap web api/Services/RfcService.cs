﻿using System;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using SAP.Middleware.Connector;
using SapService.Models;

namespace SapService.Services
{
    internal sealed class RfcService : IRfcService
    {
        private readonly IRfcConnectionPool _connectionPool;

        public RfcService(IRfcConnectionPool connectionPool)
            => _connectionPool = connectionPool;

        public async Task<RfcResponse> ExecuteRfcAsync(RfcRequest request)
        {
            var dest = await _connectionPool.GetRfcDestination(request.FuncName);
            var function = CreateFunctionWithRetry(dest, request.FuncName);
            try
            {
                await Task.Run(() => SetInputParameters(function, request.Input));
                await Task.Run(() => function.Invoke(dest));
                return await Task.Run(() => GetOutputResults(function, request.Output));
            }
            finally
            {
                ReleaseFunction(function);
            }
        }

        private IRfcFunction CreateFunctionWithRetry(RfcDestination dest, string funcName, int retryCount = 2)
        {
            while (retryCount-- > 0)
            {
                try
                {
                    return dest.Repository.CreateFunction(funcName);
                }
                catch(RfcFunctionNotFoundException) when (retryCount > 0)
                {
                    System.Threading.Thread.Sleep(100);
                }
            }
            return dest.Repository.CreateFunction(funcName);
        }

        private void SetInputParameters(IRfcFunction function, InputParams input)
        {
            if (input.InValue != null)
            {
                foreach (var value in input.InValue)
                {
                    function.SetValue(value.Key, value.Value);
                }
            }

            if (input.Table != null)
            {
                foreach (var table in input.Table)
                {
                    IRfcTable rfcTable = function.GetTable(table.Key);
                    rfcTable.Append();

                    foreach (var field in table.Value)
                    {
                        rfcTable.SetValue(field.Key, field.Value.ToString());
                    }
                }
            }
        }

        private static readonly Regex _regex = new Regex(@"FIELD (\w+)=([^ ]*)", RegexOptions.Compiled | RegexOptions.IgnoreCase);

        private RfcResponse GetOutputResults(IRfcFunction function, OutputParams output)
        {
            var response = new RfcResponse();

            foreach (var value in output.OutValue)
            {
                response.OutputValues[value] = function.GetString(value);
            }

            foreach (var table in output.Table)
            {
                var tableData = function.GetTable(table)
                    .Cast<IRfcStructure>()
                    .Select(s => _regex.Matches(s.ToString())
                        .Cast<Match>()
                        .ToDictionary(m => m.Groups[1].Value, m => m.Groups[2].Value))
                    .ToList();

                response.OutputTables[table] = tableData;
            }

            return response;
        }

        private void ReleaseFunction(IRfcFunction function)
        {
            if (function is IDisposable disposable)
            {
                disposable.Dispose();
            }
            else
            {
                var disposeMethod = function.GetType().GetMethod("Dispose",
                    System.Reflection.BindingFlags.Instance |
                    System.Reflection.BindingFlags.NonPublic);
                disposeMethod?.Invoke(function, null);
            }
        }
    }
}