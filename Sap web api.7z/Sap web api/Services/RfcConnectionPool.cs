﻿using SAP.Middleware.Connector;
using System;
using System.Collections.Concurrent;
using System.Threading;
using System.Threading.Tasks;

namespace SapService.Services
{
    internal sealed class RfcConnectionPool : IRfcConnectionPool
    {
        private readonly ConcurrentDictionary<string, (Lazy<RfcDestination>, IDestinationConfiguration)> _connections;
        private readonly IRfcConfigReader _configReader;

        public RfcConnectionPool(IRfcConfigReader configReader)
            => (_configReader, _connections) = (configReader, new ConcurrentDictionary<string, (Lazy<RfcDestination>, IDestinationConfiguration)>(StringComparer.OrdinalIgnoreCase));

        public async Task<RfcDestination> GetRfcDestination(string funcName)
            => await Task.FromResult(_connections.GetOrAdd(funcName, key =>
            {
                var config = new DestinationConfigWrapper(_configReader, key);
                RfcDestinationManager.RegisterDestinationConfiguration(config);

                var dest = new Lazy<RfcDestination>(() =>
                    RfcDestinationManager.GetDestination(key),
                    LazyThreadSafetyMode.ExecutionAndPublication);

                return (dest, config);
            }).Item1.Value);

        public void Dispose()
        {
            foreach (var connection in _connections.Values)
            {
                RfcDestinationManager.UnregisterDestinationConfiguration(connection.Item2);
            }
            _connections.Clear();
        }

        private class DestinationConfigWrapper : IDestinationConfiguration
        {
            private readonly IRfcConfigReader _configReader;
            private readonly string _funcName;

            public DestinationConfigWrapper(IRfcConfigReader configReader, string funcName)
                => (_configReader, _funcName) = (configReader, funcName);

            public RfcConfigParameters GetParameters(string destinationName)
                => _configReader.GetConfig(_funcName)?.ToRfcParameters();

            public bool ChangeEventsSupported() => false;
            public event RfcDestinationManager.ConfigurationChangeHandler ConfigurationChanged;
        }
    }
}