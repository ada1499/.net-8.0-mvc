﻿using SAP.Middleware.Connector;
using SapService.Models;
using System.Threading.Tasks;

namespace SapService.Services
{
    public interface IRfcConfigReader
    {
        RfcConfig GetConfig(string funcName);
    }

    public interface IRfcConnectionPool
    {
        Task<RfcDestination> GetRfcDestination(string funcName);
    }

    public interface IRfcService
    {
        Task<RfcResponse> ExecuteRfcAsync(RfcRequest request);
    }
}